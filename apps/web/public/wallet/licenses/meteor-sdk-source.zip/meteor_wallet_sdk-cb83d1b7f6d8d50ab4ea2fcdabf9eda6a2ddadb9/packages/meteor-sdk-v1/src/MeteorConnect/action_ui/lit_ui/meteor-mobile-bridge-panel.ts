import {
  describeCloseOptions,
  isTerminalPhase,
  type TSessionCloseOperation,
} from "@meteorwallet/connect";
import { EErr_Bridge_Session } from "@meteorwallet/connect-shared";
import { css, html, LitElement } from "lit";
import { property, query, state } from "lit/decorators.js";
import { keyed } from "lit/directives/keyed.js";
import "./meteor-wallet-continuation";
import { meteorWarning } from "./graphical/meteor-warning";
import { METEOR_QR_SIZE, METEOR_QR_COMPACT_SIZE, METEOR_QR_FRAME_PADDING } from "./meteor-qr-layout";
import QRCodeStyling from "qr-code-styling";
import type {
  IMobileBridgeSnapshot,
  MobileBridgeSession,
  TMobileBridgePhase,
} from "../../target_clients/mobile_bridge/MobileBridgeSession";
import {
  mobileBridgeRetryableFailure,
  type TMobileBridgeRetryableFailure,
} from "../mobile-bridge-availability";
import { isMobile } from "../utils/isMobile";
import { customElement } from "./custom-element";

/**
 * Button copy for the ONE close operation §5.7 permits the partner in the current phase. The
 * matrix itself is never re-derived here — `describeCloseOptions` names the operation and this
 * map only labels it, so a new operation upstream is a compile error rather than a wrong button.
 */
const CLOSE_OPERATION_COPY: Record<
  TSessionCloseOperation,
  { label: string; note?: string; confirmLabel?: string; confirmNote?: string }
> = {
  close_session: { label: "Cancel request" },
  request_close_after_turn: {
    label: "Cancel request",
    note: "The wallet is holding this request — the connection closes as soon as it is done with it.",
  },
  abandon_result_and_close: {
    label: "Discard result & close",
    confirmLabel: "Discard the signed result",
    confirmNote:
      "The wallet already answered this request. Discarding throws that signed result away — it cannot be recovered, and the request has to be made again.",
  },
  // Wallet-role operations; unreachable from this partner-side panel, present for exhaustiveness.
  wallet_abandon_action_and_close: { label: "Close" },
  request_close_after_result_ack: { label: "Close" },
};

const scanHeading = html`Scan with your mobile device <svg class="scan-phone" viewBox="0 0 16 24" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M3 0h10a2 2 0 0 1 2 2v20a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2Zm0 3v16h10V3H3Zm3-2v1h4V1H6Zm2 19a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"/></svg>`;

const svg_qr_glyph = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="6.4" height="6.4" rx="1.4"/><rect x="14.1" y="3.5" width="6.4" height="6.4" rx="1.4"/><rect x="3.5" y="14.1" width="6.4" height="6.4" rx="1.4"/><path d="M14.1 14.1h2.6v2.6h-2.6zM17.9 17.9h2.6v2.6h-2.6z"/></svg>`;

/**
 * White border drawn inside the code's own canvas. Kept small on purpose — the code already sits on
 * a white card inside a dark panel, so the card edge is the quiet zone a scanner keys on, and every
 * pixel spent here is a pixel not spent on module size.
 */
const QR_QUIET_ZONE_PX = 4;
/**
 * Only used when the host div has not been laid out yet and measures 0 — the smallest box any stage
 * gives the code (`--qr-size` on `.request-access.stacked`). Never the size a laid-out code draws
 * at.
 */
const QR_MIN_BOX_PX = 132;

/**
 * Phases a returning tab resumes into while its bridge link re-establishes. PIN entry is absent on
 * purpose: it is interactive, and its stage already carries its own link status.
 */
const RESUMABLE_PHASES: readonly TMobileBridgePhase[] = [
  "waiting_for_wallet",
  "wallet_confirmation",
  "wallet_action",
];

@customElement("meteor-mobile-bridge-panel")
export class MeteorMobileBridgePanel extends LitElement {
  @property({ attribute: false }) session?: MobileBridgeSession;
  @property({ type: Boolean, reflect: true }) contextual = false;
  @property({ type: Boolean, reflect: true }) connectDesign = false;
  @property({ type: Boolean, reflect: true }) continuation = false;
  @property({ attribute: false }) openInApp?: () => void | Promise<void>;
  @property({ attribute: false }) refreshCode?: () => Promise<void>;
  @property({ attribute: false }) resetIdentity?: () => Promise<void>;
  /** Wallet name shown in all copy — "Meteor Mobile" by default; transfer-to-web passes "Meteor Web". */
  @property() walletLabel = "Meteor Mobile";
  /**
   * Which kind of device the targeted wallet runs on — steers copy like "Scan or open …" (a
   * phone can scan the QR; a web wallet opens in a browser window instead).
   */
  @property() walletPlatform: "mobile" | "web" | "extension" = "mobile";
  @state() private snapshot?: IMobileBridgeSnapshot;
  @state() private showQr = !isMobile();
  /**
   * The PIN stage keeps its fallback QR collapsed by default — the wallet is demonstrably awake
   * there (it is displaying the PIN), so the QR is the rarer of the two escapes and must not push
   * the PIN cells off screen.
   */
  @state() private pinQrOpen = false;
  @state() private pin = "";
  @state() private pinPending = false;
  @state() private pinShake = false;
  @state() private interactionError?: string;
  @state() private resetConfirmation = false;
  @state() private resetPending = false;
  @state() private closeConfirmation = false;
  @state() private closePending = false;
  @state() private reconnectPending = false;
  /** A replacement request (`refreshCode`) is being prepared. */
  @state() private refreshPending = false;
  @state() private now = Date.now();
  @state() private presentedPushStage: "sending" | "sent" | "review" = "sending";
  @query("#mobile-bridge-qr") private qrTarget?: HTMLDivElement;
  @query("input") private pinInput?: HTMLInputElement;
  @state() private pinFocused = false;
  private unsubscribe?: () => void;
  private qr?: QRCodeStyling;
  private qrValue?: string;
  /** Box the current code was drawn into, so a stage swap to a different `--qr-size` redraws. */
  private qrSize?: number;
  private pinWasFocused = false;
  private lastPinError?: string;
  private timer?: ReturnType<typeof setInterval>;
  private pinShakeTimer?: ReturnType<typeof setTimeout>;
  private presentationTimer?: ReturnType<typeof setTimeout>;
  private presentationStartedAt = Date.now();
  private boundSession?: MobileBridgeSession;

  static styles = css`
    :host {
      /* Shared Meteor Connect button/accent tokens — keep in sync with meteor-action-button. */
      --mc-primary-a: 62, 19, 231;
      --mc-primary-b: 89, 47, 254;
      --mc-secondary-a: 30, 30, 61;
      --mc-secondary-b: 30, 32, 65;
      /* Text/surface tokens follow the surrounding Meteor Connect modal palette
         (--meteor-text-on-dark-* / --meteor-dark-gray-* come from meteor-action-ui-container). */
      --mc-ink: rgb(var(--meteor-text-on-dark-light, 245, 243, 255));
      --mc-body: rgb(var(--meteor-text-on-dark-standard, 190, 190, 230));
      --mc-muted: rgb(var(--meteor-text-on-dark-dark, 154, 151, 190));
      --mc-kicker: rgb(var(--meteor-text-on-dark-dark, 154, 151, 190));
      --mc-hairline: rgba(255, 255, 255, 0.08);
      --mc-green: 105, 215, 169;
      --mc-red: 255, 138, 134;
      --mc-amber: 255, 200, 130;
      display: block;
      width: 100%;
    }

    /* ---------- Card shell ---------- */
    .panel { position: relative; isolation: isolate; overflow: hidden; display: flex; flex-direction: column; gap: .32rem; align-items: center; padding: .45rem .8rem; border: 1px solid rgba(150,140,255,.13); border-radius: .9rem; background: linear-gradient(155deg, rgba(var(--meteor-dark-gray-lightest, 34,34,41), .32), rgba(var(--meteor-dark-gray-darkest, 14,14,23), .55) 70%); box-shadow: inset 0 2px 16px rgba(0,0,0,.22), inset 0 1px rgba(255,255,255,.035); box-sizing: border-box; }
    .panel::before { content: ""; position: absolute; width: 240px; height: 240px; left: -90px; top: -110px; z-index: -1; border-radius: 50%; background: radial-gradient(circle, rgba(105,79,244,.12), transparent 68%); pointer-events: none; }
    .panel::after { content: ""; position: absolute; width: 200px; height: 200px; right: -90px; bottom: -120px; z-index: -1; border-radius: 50%; background: radial-gradient(circle, rgba(69,193,255,.07), transparent 70%); pointer-events: none; }
    :host([contextual]) .panel { padding: .9rem; }
    .heading { display: flex; flex-direction: column; gap: .26rem; align-items: center; }
    .title { font-size: calc(.72rem - var(--mc-font-size-reduction, 0px)); font-weight: 700; text-transform: uppercase; letter-spacing: .08rem; color: var(--mc-kicker); }
    .status { margin: 0; font-size: calc(.82rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1.15rem); color: var(--mc-body); }
    .muted { color: var(--mc-muted); font-size: calc(.73rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, .95rem); }
    .error { color: rgb(var(--mc-red)); font-size: calc(.76rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1rem); }
    .fineprint { margin: 0; color: var(--mc-muted); font-size: calc(.66rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, .9rem); word-break: break-word; opacity: .85; }

    /* ---------- Buttons (mirrors meteor-action-button) ---------- */
    button { display: inline-flex; align-items: center; justify-content: center; gap: .4rem; min-height: 2.55rem; border: 0; border-radius: .65rem; padding: .68rem .95rem; box-sizing: border-box; font-family: inherit; font-size: calc(.84rem - var(--mc-font-size-reduction, 0px)); font-weight: 700; letter-spacing: .035rem; line-height: var(--mc-line-height, 1em); white-space: nowrap; cursor: pointer; color: white; background: linear-gradient(135deg, rgba(var(--mc-primary-a), .8) 0%, rgba(var(--mc-primary-b), .7) 100%); filter: drop-shadow(0 3px 10px rgba(0, 0, 0, .2)); transition: transform 120ms ease, background 120ms ease; }
    button:hover:not(:disabled) { background: linear-gradient(135deg, rgba(var(--mc-primary-a), 1) 0%, rgba(var(--mc-primary-b), .85) 100%); transform: translateY(-1px); }
    button:active:not(:disabled) { transform: translateY(0); }
    button.secondary { background: linear-gradient(135deg, rgba(var(--mc-secondary-a), .8) 0%, rgba(var(--mc-secondary-b), .7) 100%); }
    button.secondary:hover:not(:disabled) { background: linear-gradient(135deg, rgba(var(--mc-secondary-a), 1) 0%, rgba(var(--mc-secondary-b), 1) 100%); }
    button.ghost { min-height: 1.9rem; padding: .38rem .68rem; font-size: calc(.72rem - var(--mc-font-size-reduction, 0px)); background: rgba(255,255,255,.08); filter: none; }
    button.ghost:hover:not(:disabled) { background: rgba(255,255,255,.13); }
    button.icon-toggle { min-width: 2.55rem; padding: .5rem; }
    button.icon-toggle svg { width: 1.15rem; height: 1.15rem; }
    button.icon-toggle[aria-pressed="true"] { background: linear-gradient(135deg, rgba(var(--mc-primary-a), .55) 0%, rgba(var(--mc-primary-b), .45) 100%); }
    button:disabled { opacity: .55; cursor: default; }
    button:focus-visible { outline: 2px solid rgba(155,140,255,.95); outline-offset: 2px; }
    .spinner { display: inline-block; width: .9rem; height: .9rem; border: 2px solid rgba(255,255,255,.38); border-top-color: white; border-radius: 50%; animation: spin .7s linear infinite; vertical-align: middle; }
    .mini-loader { width: 1rem; height: 1rem; border: 2px solid rgba(255,255,255,.25); border-top-color: rgba(255,255,255,.95); border-radius: 50%; animation: spin .75s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* ---------- Status pills ---------- */
    .pill { display: inline-flex; align-items: center; gap: .42rem; padding: .38rem .68rem; border-radius: 999px; font-size: calc(.7rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1); border: 1px solid var(--mc-hairline); color: var(--mc-muted); background: rgba(255,255,255,.05); }
    .pill.good { border-color: rgba(var(--mc-green), .22); color: rgb(174,229,207); background: rgba(58,172,129,.09); }
    .pill.warn { border-color: rgba(var(--mc-amber), .25); color: rgb(var(--mc-amber)); background: rgba(255,187,105,.08); }
    .pill.bad { border-color: rgba(var(--mc-red), .25); color: rgb(var(--mc-red)); background: rgba(255,120,120,.08); }
    .pill-dot { width: .42rem; height: .42rem; border-radius: 50%; background: currentColor; box-shadow: 0 0 0 4px rgba(255,255,255,.06); }
    .pill.good .pill-dot { animation: dot-pulse 1.4s ease-in-out infinite; }

    /* ---------- QR / waiting card ---------- */
    /* 168px is what this screen can actually afford: it shares the modal with the platform picker,
       and the controls column beside the code still has to fit "Open <wallet>" on one line. */
    .request-access { --qr-size: 168px; display: flex; align-items: center; justify-content: center; gap: .7rem; width: 100%; }
    /* Stacked, the code no longer shares its row with the controls — it pays full height for its
       size, and this screen also carries the platform picker above it. Keep the box near its
       original footprint; level L alone still buys this layout a third more module size. */
    .request-access.stacked { --qr-size: 132px; flex-direction: column; gap: .55rem; }
    .request-controls { display: flex; flex: 1; min-width: 0; flex-direction: column; align-items: center; justify-content: center; gap: .55rem; }
    .request-access.stacked .request-controls { flex: none; }
    .actions { display: flex; gap: .5rem; flex-wrap: wrap; justify-content: center; }
    .qr-frame { position: relative; flex: 0 0 auto; padding: 2px; border-radius: 12px; background: linear-gradient(150deg, rgba(139,119,255,.55), rgba(69,50,160,.2) 55%, rgba(69,193,255,.3)); box-shadow: 0 10px 26px rgba(30,15,90,.35); }
    /* Every stage sets its own --qr-size against the room it actually has; drawQr() measures this
       box, so CSS is the only place the drawn size is decided. */
    .qr { width: var(--qr-size, 168px); height: var(--qr-size, 168px); display: grid; place-items: center; padding: 0; box-sizing: border-box; border-radius: 10px; background: white; overflow: hidden; }
    .countdown { display: inline-flex; align-items: center; gap: .4rem; font-size: calc(.71rem - var(--mc-font-size-reduction, 0px)); color: var(--mc-muted); font-variant-numeric: tabular-nums; }
    .countdown.urgent { color: rgb(var(--mc-amber)); }
    .live-footer { display: flex; flex-direction: column; align-items: center; gap: .45rem; width: 100%; }
    .link-offline { display: flex; flex-direction: column; align-items: center; gap: .4rem; }
    .close-control { display: flex; flex-direction: column; align-items: center; gap: .35rem; text-align: center; }
    .countdown-ring { width: .58rem; height: .58rem; border-radius: 50%; border: 2px solid currentColor; border-top-color: transparent; opacity: .75; animation: spin 2.4s linear infinite; }

    :host([connectdesign]) section.panel { background: #12121D; border: 0; box-shadow: none; padding: .5rem 0 .75rem; }
    :host([connectdesign]) .heading .title { display: none; }
    :host([connectdesign]) .heading .status, .connect-loading p { font-family: 'Gilroy', sans-serif; font-weight: 400; font-style: normal; font-size: calc(20px - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 50px); letter-spacing: 0px; vertical-align: bottom; }
    :host([connectdesign]) .heading .status { color: #fff; margin: 0 0 .5rem; }
    :host([connectdesign]) .request-access { --qr-size: ${METEOR_QR_SIZE}px; flex-direction: column; gap: .65rem; }
    :host([connectdesign]) .request-controls { flex: none; gap: .5rem; }
    :host([connectdesign]) .qr-frame { background: white; padding: ${METEOR_QR_FRAME_PADDING}px; box-shadow: none; }
    :host([connectdesign]) .countdown { font-size: calc(.95rem - var(--mc-font-size-reduction, 0px)); color: #999; }
    :host([connectdesign]) .countdown.urgent { color: rgb(var(--mc-amber)); }
    :host([connectdesign]) .request-controls button { background: linear-gradient(110deg, #4210ec, #602cff); border-radius: .4rem; font-size: calc(.95rem - var(--mc-font-size-reduction, 0px)); }
    :host([connectdesign]) .panel::before, :host([connectdesign]) .panel::after { display: none; }
    @media (max-height: 760px) {
      :host([connectdesign]) .request-access { --qr-size: ${METEOR_QR_COMPACT_SIZE}px; gap: .5rem; }
      :host([connectdesign]) .request-controls { gap: .5rem; }
      :host([connectdesign]) .heading .status { margin-bottom: .25rem; }
      :host([connectdesign]) .loading-code { height: 180px; }
    }
    /* Compact tier (NEAR Connect's 557px-tall frame): same QR size, tighter card. */
    @media (max-height: 640px) {
      :host([connectdesign]) section.panel { padding: .35rem 0 .5rem; }
      :host([connectdesign]) .heading .status { margin-bottom: .1rem; }
      :host([connectdesign]) .request-access { gap: .4rem; }
    }
    .connect-loading { display: flex; flex-direction: column; align-items: center; background: #12121D; border-radius: .4rem; padding: 1rem; color: white; }
    .connect-loading p { margin: 0; }
    :host([connectdesign]) .qr-status,
    :host([connectdesign]) .request-controls > .countdown { min-height: 18px; display: inline-flex; align-items: center; }
    :host([connectdesign]) .loading-frame,
    :host([connectdesign]) .loading-placeholder { background: transparent; }
    .loading-placeholder .spinner { width: 2.7rem; height: 2.7rem; border-width: 5px; }
    .scan-phone { display: inline-block; width: .7em; height: 1.1em; margin-left: .3em; vertical-align: -.15em; }
    .loading-code { height: 216px; display: grid; place-items: center; }
    .loading-code .spinner { width: 2.7rem; height: 2.7rem; border-width: 5px; }
    .loading-copy { color: #999; font-family: 'Gilroy', sans-serif; font-weight: 400; font-style: normal; font-size: calc(16px - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 18px); letter-spacing: 0px; text-align: center; vertical-align: bottom; }

    .continuation-qr { --qr-size: ${METEOR_QR_SIZE}px; }
    @media (max-height: 760px) { .continuation-qr { --qr-size: ${METEOR_QR_COMPACT_SIZE}px; } }
    :host section.panel.error-panel { padding: 0; background: #12121D; border: 0; border-radius: .4rem; box-shadow: none; }
    .error-panel::before, .error-panel::after { display: none; }
    .error-card { width: 100%; box-sizing: border-box; padding: 1.5rem; text-align: center; color: #fff; }
    .warning-asset { display: block; width: 96px; height: auto; margin: .5rem auto 1.5rem; }
    .error-card h2 { margin: 0 0 .4rem; font-size: 18px; font-weight: 600; line-height: normal; }
    .error-description { margin: 0; color: #999; font-size: 14px; font-weight: 400; line-height: normal; overflow-wrap: anywhere; }
    .error-message { margin-top: 1.25rem; }
    .error-message p { margin: 0; text-align: left; padding: .85rem 1rem; border-radius: .25rem; background: #181823; color: #fff; font-size: 14px; font-weight: 400; line-height: normal; white-space: pre-wrap; overflow-wrap: anywhere; user-select: text; }
    .error-actions { display: flex; flex-direction: column; align-items: center; gap: .6rem; margin-top: 1.25rem; }
    /* The approved primary platform-button treatment (UI_STANDARD.md "Surfaces and controls"). */
    .error-actions button { min-width: 10rem; min-height: 3rem; padding: .65rem .8rem; border-radius: .4rem; background: linear-gradient(110deg, #4210ec, #602cff); filter: none; font-size: 16px; font-weight: 600; letter-spacing: 0; line-height: normal; }
    .error-actions button:hover:not(:disabled) { background: linear-gradient(110deg, #4210ec, #602cff); filter: brightness(1.15); transform: none; }
    .error-actions button:disabled { opacity: 1; cursor: wait; }
    /* NEAR Connect's compact frames: the card gives up room so the chooser above never scrolls. */
    @media (max-height: 640px) {
      .error-card { padding: 1rem; }
      .warning-asset { width: 64px; margin: .25rem auto .9rem; }
      .error-actions { margin-top: .9rem; }
      .error-actions button { min-height: 2.6rem; padding-top: .4rem; padding-bottom: .4rem; }
    }
    /* ---------- Stage cards (push / review / pin / status) ---------- */
    .stage-panel { height: 292px; justify-content: center; }
    .stage-panel.auto { height: auto; min-height: 292px; padding: 1rem .9rem; }
    .stage-panel.slim { height: auto; min-height: 190px; }
    .stage { width: 100%; min-height: 258px; display: flex; align-items: center; justify-content: center; animation: stage-in .42s cubic-bezier(.16,1,.3,1) both; }
    .stage.compact { min-height: 0; flex-direction: column; gap: .6rem; text-align: center; padding: .35rem 0; }
    .push-layout { width: 100%; display: grid; grid-template-columns: minmax(0,1fr) 176px; align-items: center; gap: .7rem; }
    .stage-primary { min-width: 0; min-height: 220px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: .55rem; text-align: center; }
    .stage-kicker { color: var(--mc-kicker); font-size: calc(.72rem - var(--mc-font-size-reduction, 0px)); font-weight: 700; letter-spacing: .08rem; text-transform: uppercase; }
    .stage-title { min-height: 2.44rem; max-width: 10.2rem; margin: 0; display: flex; align-items: center; justify-content: center; color: var(--mc-ink); font-size: calc(1.03rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1.22rem); font-weight: 750; text-wrap: balance; }
    .stage-subtitle { min-height: 2rem; max-width: 10.2rem; margin: 0; display: flex; align-items: center; color: var(--mc-muted); font-size: calc(.74rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1rem); text-wrap: balance; }
    .stage-icon { position: relative; width: 66px; height: 66px; display: grid; place-items: center; border-radius: 21px; color: white; background: linear-gradient(145deg, rgba(112,88,248,.95), rgba(63,44,165,.9)); box-shadow: 0 12px 34px rgba(62,38,184,.35), inset 0 1px rgba(255,255,255,.2); }
    .stage-icon svg { width: 31px; height: 31px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
    .stage-icon.small { width: 48px; height: 48px; border-radius: 15px; }
    .stage-icon.small svg { width: 23px; height: 23px; }
    .stage-icon.sending::before, .stage-icon.sending::after { content: ""; position: absolute; inset: -7px; border: 1px solid rgba(139,119,255,.32); border-radius: 26px; animation: notify-pulse 1.7s ease-out infinite; }
    .stage-icon.sending::after { animation-delay: .65s; }
    .stage-icon.sent, .stage-icon.good { background: linear-gradient(145deg, #40bc86, #227a61); box-shadow: 0 12px 34px rgba(32,157,109,.27), inset 0 1px rgba(255,255,255,.2); }
    .stage-icon.unavailable, .stage-icon.neutral { background: linear-gradient(145deg, #8a718f, #51425e); }
    .status-line { min-height: 1rem; display: flex; align-items: center; justify-content: center; gap: .4rem; color: var(--mc-body); font-size: calc(.7rem - var(--mc-font-size-reduction, 0px)); }
    .fallback-slot { --qr-size: 176px; width: 176px; min-height: 220px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: .38rem; }
    .fallback-label { min-height: .85rem; color: var(--mc-kicker); font-size: calc(.66rem - var(--mc-font-size-reduction, 0px)); font-weight: 700; letter-spacing: .06rem; text-transform: uppercase; }
    .fallback-slot .error { font-size: calc(.66rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, .9rem); text-wrap: balance; }
    .qr-placeholder { width: calc(var(--qr-size, 168px) + 4px); height: calc(var(--qr-size, 168px) + 4px); display: grid; place-items: center; box-sizing: border-box; border: 1px solid var(--mc-hairline); border-radius: 11px; overflow: hidden; color: var(--mc-muted); font-size: calc(.68rem - var(--mc-font-size-reduction, 0px)); background: linear-gradient(110deg, rgba(255,255,255,.035) 20%, rgba(255,255,255,.08) 38%, rgba(255,255,255,.035) 56%); background-size: 220% 100%; animation: qr-shimmer 1.8s linear infinite; }

    /* ---------- Review stage ---------- */
    .review-stage { flex-direction: column; gap: .65rem; text-align: center; }
    .review-visual { position: relative; width: 88px; height: 88px; display: grid; place-items: center; }
    .review-visual::before, .review-visual::after { content: ""; position: absolute; inset: 5px; border-radius: 50%; border: 1px solid rgba(103,220,181,.3); animation: review-pulse 2s ease-out infinite; }
    .review-visual::after { animation-delay: .8s; }
    .review-visual.violet::before, .review-visual.violet::after { border-color: rgba(139,119,255,.34); }
    .review-phone { position: relative; width: 42px; height: 68px; display: grid; place-items: center; border: 2px solid rgba(244,242,255,.92); border-radius: 11px; background: linear-gradient(160deg, rgba(93,72,212,.92), rgba(34,27,78,.96)); box-shadow: 0 13px 35px rgba(63,41,174,.42); }
    .review-phone::before { content: ""; position: absolute; width: 13px; height: 2px; top: 5px; border-radius: 2px; background: rgba(255,255,255,.6); }
    /* Browser-window variant of the device visual, used when the paired wallet is a web wallet. */
    .review-phone.web { width: 66px; height: 48px; border-radius: 8px; }
    .review-phone.web::before { width: 30px; left: 7px; top: 6px; }
    /* Compact variant, used wherever the device visual shares its row with the fallback QR. */
    .review-visual.compact { width: 66px; height: 66px; }
    .review-phone.compact { width: 34px; height: 54px; border-radius: 9px; }
    .review-phone.compact.web { width: 54px; height: 40px; border-radius: 7px; }
    .review-phone.compact.web::before { width: 24px; left: 6px; top: 5px; }
    .review-check { width: 18px; height: 9px; margin-top: -2px; border-left: 2px solid #82ebbd; border-bottom: 2px solid #82ebbd; transform: rotate(-45deg); }
    .phone-pin-dots { display: flex; gap: 3px; margin-top: -2px; }
    .phone-pin-dots span { width: 5px; height: 5px; border-radius: 50%; background: rgba(210,200,255,.95); box-shadow: 0 0 6px rgba(170,150,255,.8); animation: phone-dot 1.6s ease-in-out infinite; }
    .phone-pin-dots span:nth-child(2) { animation-delay: .18s; }
    .phone-pin-dots span:nth-child(3) { animation-delay: .36s; }
    .phone-pin-dots span:nth-child(4) { animation-delay: .54s; }
    .review-title { max-width: 18rem; margin: 0; color: var(--mc-ink); font-size: calc(1.18rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1.35rem); font-weight: 760; text-wrap: balance; }
    .review-subtitle { max-width: 17rem; margin: 0; color: var(--mc-muted); font-size: calc(.78rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1.05rem); }

    /* ---------- PIN stage ---------- */
    .pin-stage { flex-direction: column; gap: .55rem; text-align: center; min-height: 0; }
    .pin-row { position: relative; display: flex; gap: .55rem; justify-content: center; padding: .2rem 0; }
    .pin-row.shake { animation: pin-shake .45s cubic-bezier(.36,.07,.19,.97) both; }
    .pin-cell { width: 50px; height: 58px; display: grid; place-items: center; font-size: calc(1.45rem - var(--mc-font-size-reduction, 0px)); font-weight: 800; color: var(--mc-ink); border-radius: .8rem; border: 1px solid var(--mc-hairline); background: linear-gradient(160deg, rgba(255,255,255,.05), rgba(255,255,255,.015)); box-shadow: inset 0 1px rgba(255,255,255,.04), 0 4px 14px rgba(0,0,0,.25); transition: border-color 140ms ease, box-shadow 140ms ease, transform 140ms ease; }
    .pin-cell.filled { border-color: rgba(139,122,255,.7); transform: translateY(-1px); }
    .pin-cell.active { border-color: rgba(160,140,255,.95); box-shadow: inset 0 1px rgba(255,255,255,.06), 0 0 0 3px rgba(112,86,237,.22), 0 4px 16px rgba(52,30,150,.35); }
    .pin-row.error .pin-cell { border-color: rgba(var(--mc-red), .65); }
    .pin-caret { width: 2px; height: 1.3rem; border-radius: 2px; background: #b9a8ff; animation: caret-blink 1.1s steps(2, start) infinite; }
    .pin-hidden-input { position: absolute; inset: 0; width: 100%; height: 100%; box-sizing: border-box; opacity: 0; border: 0; padding: 0; margin: 0; background: transparent; color: transparent; caret-color: transparent; font-size: calc(16px - var(--mc-font-size-reduction, 0px)); text-align: center; outline: none; cursor: pointer; }
    .pin-actions { display: flex; flex-direction: column; align-items: center; gap: .45rem; width: 100%; }
    .pin-verify { min-width: 232px; }
    /* The PIN stage carries the most content of any stage — with the Open/QR escapes added below
       the attempts pill, the device visual is what gives up the room to keep the modal in bounds. */
    .pin-stage .review-visual { width: 74px; height: 74px; }
    .pin-stage .review-phone { width: 38px; height: 60px; border-radius: 10px; }
    /* The PIN stage is full before the code is even revealed, so opening it always scrolls — which
       is exactly why it starts collapsed. Since the scroll is unavoidable at any size (measured:
       104px still scrolls), the code may as well be big enough to scan once you have scrolled. */
    .stage-fallback { --qr-size: 176px; display: flex; flex-direction: column; align-items: center; gap: .45rem; }
    .stage-fallback-row { display: flex; gap: .45rem; flex-wrap: wrap; justify-content: center; }

    /* ---------- Identity reset ---------- */
    .reset-card { display: flex; flex-direction: column; align-items: center; gap: .5rem; max-width: 19rem; }

    @keyframes stage-in { from { opacity: 0; transform: translateY(7px) scale(.985); } to { opacity: 1; transform: translateY(0) scale(1); } }
    @keyframes notify-pulse { 0% { opacity: .8; transform: scale(.84); } 75%,100% { opacity: 0; transform: scale(1.22); } }
    @keyframes review-pulse { 0% { opacity: .75; transform: scale(.7); } 75%,100% { opacity: 0; transform: scale(1.25); } }
    @keyframes dot-pulse { 50% { opacity: .45; transform: scale(.78); } }
    @keyframes qr-shimmer { to { background-position: -220% 0; } }
    @keyframes caret-blink { 50% { opacity: 0; } }
    @keyframes phone-dot { 0%, 100% { opacity: .45; } 50% { opacity: 1; } }
    @keyframes pin-shake {
      10%, 90% { transform: translateX(-1px); }
      20%, 80% { transform: translateX(2px); }
      30%, 50%, 70% { transform: translateX(-4px); }
      40%, 60% { transform: translateX(4px); }
    }

    @media (max-width: 370px) {
      .request-access { --qr-size: 132px; flex-direction: column; }
      .request-controls { flex: none; }
      .stage-panel { height: 420px; }
      .stage-panel.auto, .stage-panel.slim { height: auto; }
      .push-layout { grid-template-columns: 1fr; }
      .stage { min-height: 386px; }
      .stage.compact, .pin-stage { min-height: 0; }
      .stage-primary { min-height: 160px; gap: .35rem; }
      .stage-primary .stage-subtitle { display: none; }
      .fallback-slot { min-height: 205px; }
      .pin-cell { width: 44px; height: 52px; font-size: calc(1.3rem - var(--mc-font-size-reduction, 0px)); }
      .pin-verify { min-width: 206px; }
    }
    @media (prefers-reduced-motion: reduce) {
      .stage, .stage-icon::before, .stage-icon::after, .review-visual::before, .review-visual::after,
      .pill-dot, .qr-placeholder, .pin-row.shake, .pin-caret, .phone-pin-dots span, .countdown-ring { animation: none !important; }
    }
  `;

  connectedCallback(): void {
    super.connectedCallback();
    this.bindSession();
    this.timer = setInterval(() => {
      this.now = Date.now();
    }, 1000);
  }

  protected willUpdate(changed: Map<PropertyKey, unknown>): void {
    if (changed.has("session")) this.bindSession();
  }

  protected updated(): void {
    const link = this.snapshot?.deepLink;
    // Any stage may host the fallback QR, so draw wherever the target actually rendered instead of
    // re-deriving which stage was supposed to own it.
    if (link != null && this.qrTarget != null)
      void this.updateComplete.then(() => this.drawQr(link));
    if (
      this.snapshot?.phase === "wallet_verification" &&
      !this.pinWasFocused &&
      this.pinInput != null
    ) {
      this.pinInput.focus();
      this.pinWasFocused = true;
    } else if (this.snapshot?.phase !== "wallet_verification") {
      this.pinWasFocused = false;
    }
  }

  disconnectedCallback(): void {
    this.unsubscribe?.();
    if (this.timer != null) clearInterval(this.timer);
    if (this.pinShakeTimer != null) clearTimeout(this.pinShakeTimer);
    if (this.presentationTimer != null) clearTimeout(this.presentationTimer);
    this.qr = undefined;
    this.qrSize = undefined;
    super.disconnectedCallback();
  }

  private bindSession(): void {
    if (this.boundSession !== this.session) {
      this.boundSession = this.session;
      this.presentedPushStage = "sending";
      this.presentationStartedAt = Date.now();
      this.closeConfirmation = false;
      this.pinQrOpen = false;
      this.interactionError = undefined;
      if (this.presentationTimer != null) clearTimeout(this.presentationTimer);
    }
    this.unsubscribe?.();
    this.unsubscribe = this.session?.subscribe((snapshot) => {
      // A failure ends every control the previous stage offered, so their errors end with it — the
      // failure card's own Try Again must not inherit an earlier "could not be opened".
      if (snapshot.phase === "failed" && this.snapshot?.phase !== "failed") {
        this.interactionError = undefined;
      }
      this.snapshot = snapshot;
      this.reconcilePinErrorPresentation(snapshot);
      this.reconcilePushPresentation(snapshot);
    });
  }

  /** Play the shake feedback exactly once per newly surfaced PIN error. */
  private reconcilePinErrorPresentation(snapshot: IMobileBridgeSnapshot): void {
    if (snapshot.pinError != null && snapshot.pinError !== this.lastPinError) {
      this.pinShake = true;
      if (this.pinShakeTimer != null) clearTimeout(this.pinShakeTimer);
      this.pinShakeTimer = setTimeout(() => {
        this.pinShake = false;
      }, 500);
    }
    this.lastPinError = snapshot.pinError;
  }

  private reconcilePushPresentation(snapshot: IMobileBridgeSnapshot): void {
    if (this.presentationTimer != null) clearTimeout(this.presentationTimer);
    const pushWasSent = snapshot.push === "delivered";
    // wallet_action is the authoritative bridge acknowledgement that Meteor Mobile received the
    // request. Do not advance the UI to approval based on push delivery alone.
    const walletReceivedRequest = snapshot.phase === "wallet_action";

    let nextStage: "sent" | "review" | undefined;
    let minimumStageDuration = 0;
    if (this.presentedPushStage === "sending" && pushWasSent) {
      nextStage = "sent";
      minimumStageDuration = 450;
    } else if (this.presentedPushStage === "sent" && walletReceivedRequest) {
      nextStage = "review";
      minimumStageDuration = 700;
    }
    if (nextStage == null) return;

    const delay = Math.max(0, minimumStageDuration - (Date.now() - this.presentationStartedAt));
    this.presentationTimer = setTimeout(() => {
      this.presentedPushStage = nextStage;
      this.presentationStartedAt = Date.now();
      this.reconcilePushPresentation(this.snapshot ?? snapshot);
    }, delay);
  }

  private drawQr(link: string): void {
    if (this.qrTarget == null) return;
    // Each stage gives the code a different box (see `--qr-size`), so CSS is the single source of
    // truth for the drawn size — measure it rather than hard-coding one. A zero measurement means
    // the host is not laid out yet; fall back to the smallest box any stage uses.
    const size = this.qrTarget.clientWidth > 0 ? this.qrTarget.clientWidth : QR_MIN_BOX_PX;
    // `updated()` fires on every tick of the 1s clock; only redraw when the link or the box
    // actually changed, or the host element is a fresh one (a stage swap hands us an empty div).
    if (this.qrValue === link && this.qrSize === size && this.qrTarget.childElementCount > 0)
      return;
    const options = {
      width: size,
      height: size,
      type: "svg" as const,
      data: link,
      // The quiet zone is deliberately thin. The spec's 4 modules would cost ~16px of a ~150px box
      // here, and the code sits on its own white card inside a dark panel — the contrast boundary
      // scanners actually key on is the card edge, which is well outside this margin.
      margin: QR_QUIET_ZONE_PX,
      qrOptions: {
        // Level L, not the library's default Q. Q buys damage tolerance a screen cannot suffer,
        // and there is no centre logo eating modules — at 147 characters it costs 57x57 modules
        // against L's 45x45, which is a third of the resolution for nothing.
        errorCorrectionLevel: "L" as const,
      },
      // Square, not rounded: at these module sizes a rounded dot is mostly anti-aliased edge, so
      // each module renders as a grey smear and the decoder loses its black/white threshold long
      // before it runs out of resolution.
      // roundSize must stay false: when true (the default) the module size is floored to whole
      // pixels, which shrinks the drawn code well inside the box we just measured.
      dotsOptions: { color: "#22105f", type: "square" as const, roundSize: false },
      backgroundOptions: { color: "#ffffff" },
    };
    if (this.qr == null) this.qr = new QRCodeStyling(options);
    else this.qr.update(options);
    this.qrValue = link;
    this.qrSize = size;
    this.qrTarget.innerHTML = "";
    this.qr.append(this.qrTarget);
  }

  private async submitPin(): Promise<void> {
    if (this.session == null || this.pinPending) return;
    this.pinPending = true;
    try {
      await this.session.submitPin(this.pin);
      this.pin = "";
      this.interactionError = undefined;
    } catch {
      // The session snapshot owns the safe, user-facing PIN error.
      this.pin = "";
      await this.updateComplete;
      this.pinInput?.focus();
    } finally {
      this.pinPending = false;
    }
  }

  private requestPinSubmission(): void {
    if (this.pinPending || this.pin.length !== 4 || (this.snapshot?.pinAttemptsUsed ?? 3) >= 3) {
      return;
    }
    void this.submitPin();
  }

  private handlePinKeyDown(event: KeyboardEvent): void {
    if (event.key !== "Enter") return;

    // This UI can run in a sandboxed iframe without `allow-forms`. Never let
    // Enter fall through to native form submission (including a host form).
    event.preventDefault();
    event.stopPropagation();
    if (event.repeat || event.isComposing) return;
    this.requestPinSubmission();
  }

  private get hideQrOnMobile(): boolean {
    return this.connectDesign && isMobile();
  }

  private get canOpenWalletOnDevice(): boolean {
    return this.walletPlatform !== "mobile" || isMobile();
  }

  private async openMobileApp(): Promise<void> {
    try {
      await this.openInApp?.();
      this.interactionError = undefined;
    } catch {
      this.interactionError =
        this.walletPlatform === "extension"
          ? "Could not open Meteor Extension. Check that it is enabled and up to date, then try again."
          : this.hideQrOnMobile ? `${this.walletLabel} could not be opened. Please try again.` : `${this.walletLabel} could not be opened automatically. Scan the QR code instead.`;
      this.showQr = !this.hideQrOnMobile;
    }
  }

  private async refreshMobileCode(): Promise<void> {
    if (this.refreshPending) return;
    this.refreshPending = true;
    try {
      await this.refreshCode?.();
      this.interactionError = undefined;
    } catch {
      this.interactionError = "A new connection code could not be created. Please try again.";
    } finally {
      this.refreshPending = false;
    }
  }

  /**
   * Copy for a request no wallet ever took part in (`mobileBridgeRetryableFailure`). The
   * classifier's headline and detail are written for integrators, so they never reach this card —
   * the container reports them to the console instead.
   */
  private retryableFailureCopy(failure: TMobileBridgeRetryableFailure): {
    title: string;
    description: string;
  } {
    // A QR is what this panel offers only for a phone wallet scanned from another screen.
    const qr = this.walletPlatform === "mobile" && !this.hideQrOnMobile;
    if (failure === "not_created") {
      return qr
        ? {
            title: "Couldn’t Generate QR Code",
            description: `We couldn’t create a secure QR code for ${this.walletLabel}. Please try again.`,
          }
        : {
            title: `Couldn’t Connect to ${this.walletLabel}`,
            description: "We couldn’t set up a secure connection. Please try again.",
          };
    }
    return qr
      ? {
          title: "QR Code Expired",
          description: "This QR code is no longer valid. Try again to get a new one.",
        }
      : {
          title: "Request Expired",
          description: `This request to ${this.walletLabel} is no longer valid. Try again to start a new one.`,
        };
  }

  /** "Try Again" — a fresh request, prepared exactly like the eager one. */
  private renderRetryAction() {
    if (this.refreshCode == null) return undefined;
    return html`<div class="error-actions">
      <button
        type="button"
        ?disabled=${this.refreshPending}
        aria-busy=${this.refreshPending ? "true" : "false"}
        @click=${() => void this.refreshMobileCode()}
      >
        ${this.refreshPending ? html`<span class="spinner" role="status" aria-label="Trying again"></span>` : "Try Again"}
      </button>
      ${this.interactionError ? html`<span class="error" role="alert">${this.interactionError}</span>` : ""}
    </div>`;
  }

  private async confirmIdentityReset(): Promise<void> {
    if (!this.resetConfirmation) {
      this.resetConfirmation = true;
      return;
    }
    this.resetPending = true;
    try {
      await this.resetIdentity?.();
      this.resetConfirmation = false;
      this.interactionError = undefined;
    } catch (error) {
      this.interactionError =
        error instanceof Error && error.message === "mobile_bridge_other_tab_active"
          ? `${this.walletLabel} is active in another tab. Close that request and try again.`
          : "The mobile pairing could not be reset. Please try again.";
    } finally {
      this.resetPending = false;
    }
  }

  /**
   * The one close operation §5.7 permits the partner right now, or null when none does — either
   * the facts are terminal or the phase authorizes no partner close. Never re-derived from the
   * projected flow phase: `describeCloseOptions` mirrors the server's own authorization, so a
   * button drawn from it can never click into `close_not_permitted`.
   */
  private closeOptions(snapshot: IMobileBridgeSnapshot) {
    const facts = snapshot.facts;
    if (facts == null || isTerminalPhase(facts)) return null;
    const options = describeCloseOptions(facts, "partner");
    return options.operation == null ? null : { ...options, operation: options.operation };
  }

  private async performClose(destructive: boolean): Promise<void> {
    if (this.closePending) return;
    if (destructive && !this.closeConfirmation) {
      this.closeConfirmation = true;
      return;
    }
    this.closePending = true;
    try {
      // `abandon()` sends exactly the operation `describeCloseOptions` named — the SDK owns the
      // verb and its signed challenge; this panel only labels and triggers it.
      await this.session?.abandon();
      this.closeConfirmation = false;
      this.interactionError = undefined;
    } catch {
      this.interactionError = "The request could not be closed. Please try again.";
    } finally {
      this.closePending = false;
    }
  }

  private async reconnectLink(): Promise<void> {
    if (this.reconnectPending) return;
    this.reconnectPending = true;
    try {
      await this.session?.reconnectLink();
      this.interactionError = undefined;
    } catch {
      this.interactionError = `The secure connection to ${this.walletLabel} could not be restored. Please try again.`;
    } finally {
      this.reconnectPending = false;
    }
  }

  private statusText(snapshot: IMobileBridgeSnapshot): string {
    switch (snapshot.phase) {
      case "initializing":
        return "Initializing secure connection…";
      case "busy_other_tab":
        return `${this.walletLabel} is busy in another tab. Retrying…`;
      case "creating_bridge":
        return "Creating secure request…";
      case "waiting_for_wallet":
        return this.walletPlatform === "mobile"
          ? `Scan or open ${this.walletLabel} to continue.`
          : `Open ${this.walletLabel} to continue.`;
      case "wallet_confirmation":
        return `Review the app details and confirm the link in ${this.walletLabel}.`;
      case "wallet_verification":
        return `Enter the 4-digit PIN shown on ${this.walletLabel}.`;
      case "wallet_action":
        return `Review and approve this request in ${this.walletLabel}.`;
      case "result_ready":
        return `Saving the signed result from ${this.walletLabel}…`;
      case "external_work":
        return "Adding the new key on-chain…";
      case "completed":
        return `Completed in ${this.walletLabel}.`;
      case "failed":
        return "The request could not be completed.";
      case "cancelled":
        return "The request was cancelled.";
    }
  }

  private formatCountdown(secondsLeft: number): string {
    return `${Math.floor(secondsLeft / 60)}:${String(secondsLeft % 60).padStart(2, "0")}`;
  }

  private renderCountdown(secondsLeft: number | undefined, label = "Code expires in") {
    if (secondsLeft == null) return "";
    const urgent = secondsLeft <= 60;
    return html`<span class=${`countdown${urgent ? " urgent" : ""}`}>
      <span class="countdown-ring" aria-hidden="true"></span>
      ${label} ${this.formatCountdown(secondsLeft)}
    </span>`;
  }

  /**
   * Bridge-link health, straight off `linkStatusChanged`. `detached`/`live`/`joining` say nothing —
   * a healthy link is not news. `reconnecting` reports the SDK's own bounded redial ladder
   * (attempt + countdown), `offline` is where that ladder gave up and the user-mediated
   * `connectBridgeLink()` takes over, and `rejected` is handled ahead of this by the
   * identity-reset screen (redialing cannot help a refused identity).
   */
  private renderLinkStatus(snapshot: IMobileBridgeSnapshot) {
    if (snapshot.linkPhase === "reconnecting") {
      const retryIn =
        snapshot.linkRetryInMs == null
          ? ""
          : ` · retrying in ${Math.ceil(snapshot.linkRetryInMs / 1000)}s`;
      const attempt =
        snapshot.linkRedialAttempt > 0 ? ` (attempt ${snapshot.linkRedialAttempt})` : "";
      return html`<span class="pill warn" role="status">
        <span class="mini-loader" aria-hidden="true"></span>
        <span>Reconnecting securely${attempt}${retryIn}</span>
      </span>`;
    }
    if (snapshot.linkPhase !== "offline") return "";
    return html`<div class="link-offline">
      <span class="pill bad" role="status">
        <span class="pill-dot"></span>
        <span>Connection lost — automatic retries stopped</span>
      </span>
      <button class="ghost" ?disabled=${this.reconnectPending} @click=${() => void this.reconnectLink()}>
        ${this.reconnectPending ? html`<span class="spinner" role="status" aria-label="Reconnecting"></span>` : "Reconnect"}
      </button>
    </div>`;
  }

  /**
   * The close control, labelled from the §5.7 matrix rather than a hard-coded "Cancel". A
   * destructive operation (discarding a signed result the wallet already produced) asks first.
   */
  private renderCloseControl(snapshot: IMobileBridgeSnapshot) {
    if (this.connectDesign) return "";
    const options = this.closeOptions(snapshot);
    if (options == null) return "";
    const copy = CLOSE_OPERATION_COPY[options.operation];
    const confirming = options.destructive && this.closeConfirmation;
    const note = confirming ? copy.confirmNote : copy.note;
    return html`<div class="close-control">
      ${note ? html`<span class="muted">${note}</span>` : ""}
      <button
        class="ghost"
        ?disabled=${this.closePending}
        @click=${() => void this.performClose(options.destructive)}
      >
        ${
          this.closePending
            ? html`<span class="spinner" role="status" aria-label="Closing"></span>`
            : confirming
              ? (copy.confirmLabel ?? copy.label)
              : copy.label
        }
      </button>
    </div>`;
  }

  /**
   * Everything that is true of a live session regardless of which stage is on screen: link health
   * and the phase-correct close verb. Terminal panels omit it — `closeOptions` already returns
   * null for terminal facts, and a released link has nothing to report.
   */
  private renderLiveFooter(snapshot: IMobileBridgeSnapshot) {
    const link = this.renderLinkStatus(snapshot);
    const close = this.renderCloseControl(snapshot);
    // "" — not an empty element — so the caller can tell whether the fixed-height stage panels
    // need to grow for it.
    if (link === "" && close === "") return "";
    return html`<div class="live-footer">${link}${close}</div>`;
  }

  /**
   * The escape hatch every non-terminal stage has to offer: this bridge's own link, as a QR and as
   * a direct "Open <wallet>" button. A delivered push is NEVER proof that the wallet surfaced the
   * request — a trusted wallet can claim the bridge from the background and land the session in
   * `wallet_action` with nothing on screen — so no stage may present waiting as the only option.
   */
  private renderFallbackSlot(snapshot: IMobileBridgeSnapshot | undefined, secondsLeft?: number) {
    if (this.walletPlatform === "extension" || this.hideQrOnMobile) {
      return html`<div class="stage-fallback">
        <button class="ghost" ?disabled=${snapshot?.deepLink == null} @click=${() => this.openMobileApp()}>Open ${this.walletLabel}</button>
        ${this.interactionError ? html`<span class="error">${this.interactionError}</span>` : ""}
      </div>`;
    }
    const deepLink = snapshot?.deepLink;
    const ready = deepLink != null;
    return html`<div class="fallback-slot">
      <span class="fallback-label">${ready ? "Scan instead" : "Preparing backup QR"}</span>
      ${
        ready && this.showQr
          ? html`<div class="qr-frame"><div id="mobile-bridge-qr" class="qr" role="img" aria-label="Scan with ${this.walletLabel}"></div></div>`
          : html`<div class="qr-placeholder">
              ${
                ready
                  ? html`<button class="ghost" @click=${() => (this.showQr = true)}>Show QR</button>`
                  : "Preparing secure code"
              }
            </div>`
      }
      ${
        ready
          ? this.canOpenWalletOnDevice ? html`<button class="ghost" @click=${() => this.openMobileApp()}>Open ${this.walletLabel}</button>` : ""
          : html`<span class="status-line">${secondsLeft == null ? "" : `Expires in ${this.formatCountdown(secondsLeft)}`}</span>`
      }
      ${this.interactionError ? html`<span class="error">${this.interactionError}</span>` : ""}
    </div>`;
  }

  private renderPushStage(
    snapshot: IMobileBridgeSnapshot | undefined,
    stage: "sending" | "sent" | "unavailable",
    secondsLeft?: number,
  ) {
    const title =
      stage === "sending"
        ? "Sending push notification to wallet"
        : stage === "sent"
          ? "Push notification sent"
          : "Push notification unavailable";
    const subtitle =
      stage === "sending"
        ? `Securely contacting your paired ${this.walletLabel} wallet.`
        : stage === "sent"
          ? `Waiting for ${this.walletLabel} to receive the request.`
          : this.walletPlatform === "extension"
            ? "Open Meteor Extension to continue."
            : `Use the secure QR code to continue in ${this.walletLabel}.`;

    return keyed(
      `push-${stage}`,
      html`<div class="stage">
        <div class="push-layout">
          <div class="stage-primary">
            <span class="stage-kicker">${this.walletLabel}</span>
            <div class=${`stage-icon ${stage}`} aria-hidden="true">
              ${
                stage === "sent"
                  ? html`<svg viewBox="0 0 24 24"><path d="m5 12.5 4.2 4.2L19 7" /></svg>`
                  : html`<svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" />${stage === "unavailable" ? html`<path d="m5 5 14 14" />` : ""}</svg>`
              }
            </div>
            <h2 class="stage-title">${title}</h2>
            <p class="stage-subtitle">${subtitle}</p>
            <div class="status-line">
              ${stage === "sending" || stage === "sent" ? html`<span class="mini-loader" aria-hidden="true"></span>` : ""}
              <span>${
                stage === "sending"
                  ? "Contacting paired device"
                  : stage === "sent"
                    ? "Waiting for wallet"
                    : this.walletPlatform === "extension"
                      ? "Open wallet to continue"
                      : "QR fallback ready"
              }</span>
            </div>
          </div>
          ${this.renderFallbackSlot(snapshot, secondsLeft)}
        </div>
      </div>`,
    );
  }

  /**
   * The wallet has claimed the bridge — but a claim can happen entirely in the background, so this
   * stage keeps the same QR/Open pair as the earlier ones rather than leaving "waiting" as the
   * user's only move.
   */
  private renderReviewStage(snapshot: IMobileBridgeSnapshot, secondsLeft?: number) {
    return keyed(
      "wallet-review",
      html`<div class="stage">
        <div class="push-layout">
          <div class="stage-primary">
            <span class="stage-kicker">Request received</span>
            <div class="review-visual compact" aria-hidden="true">
              <div class=${`review-phone compact${this.walletPlatform !== "mobile" ? " web" : ""}`}><span class="review-check"></span></div>
            </div>
            <h2 class="stage-title">Review and approve this request in ${this.walletLabel}</h2>
            <p class="stage-subtitle">${this.canOpenWalletOnDevice
              ? `Nothing showing up? Open ${this.walletLabel} again${this.walletPlatform === "extension" || this.hideQrOnMobile ? "." : " or scan the code."}`
              : "Nothing showing up? Scan the code with your mobile device."}</p>
            <div class="pill good" role="status">
              <span class="pill-dot"></span>
              <span>Waiting for your approval</span>
            </div>
          </div>
          ${this.renderFallbackSlot(snapshot, secondsLeft)}
        </div>
      </div>`,
    );
  }

  /**
   * First-pairing PIN entry, presented with the same stage treatment as the
   * "request received" screen: kicker, pulsing phone visual (showing the PIN on
   * the phone), then a segmented 4-digit input backed by one real hidden input
   * so focus, paste, mobile numeric keyboards, and screen readers keep working.
   */
  private renderPinStage(snapshot: IMobileBridgeSnapshot) {
    const attemptsLeft = Math.max(0, 3 - snapshot.pinAttemptsUsed);
    const exhausted = snapshot.pinAttemptsUsed >= 3;
    const activeIndex = Math.min(this.pin.length, 3);
    const cells = [0, 1, 2, 3].map((index) => {
      const digit = this.pin[index];
      const active = this.pinFocused && !this.pinPending && !exhausted && index === activeIndex;
      return html`<div
        class=${`pin-cell${digit != null ? " filled" : ""}${active ? " active" : ""}`}
        aria-hidden="true"
      >
        ${digit ?? (active ? html`<span class="pin-caret"></span>` : "")}
      </div>`;
    });

    return keyed(
      "wallet-pin",
      html`<div class="stage review-stage pin-stage">
        <span class="stage-kicker">Secure pairing</span>
        <div class="review-visual violet" aria-hidden="true">
          <div class=${`review-phone${this.walletPlatform !== "mobile" ? " web" : ""}`}>
            <div class="phone-pin-dots"><span></span><span></span><span></span><span></span></div>
          </div>
        </div>
        <h2 class="review-title">Enter the PIN shown on ${this.walletLabel}</h2>
        <p class="review-subtitle">
          ${this.walletLabel} is displaying a 4-digit PIN. Enter it here to securely pair this dApp with
          your wallet.
        </p>
        <div
          class=${`pin-row${this.pinShake ? " shake" : ""}${snapshot.pinError && !this.pinPending ? " error" : ""}`}
          role="group"
          aria-label="${this.walletLabel} PIN verification"
          @click=${() => this.pinInput?.focus()}
        >
          ${cells}
          <input
            class="pin-hidden-input"
            aria-label="4-digit ${this.walletLabel} PIN"
            inputmode="numeric"
            autocomplete="one-time-code"
            maxlength="4"
            .value=${this.pin}
            ?disabled=${exhausted}
            @focus=${() => (this.pinFocused = true)}
            @blur=${() => (this.pinFocused = false)}
            @input=${(event: InputEvent) => (this.pin = (event.target as HTMLInputElement).value.replace(/\D/g, "").slice(0, 4))}
            @keydown=${(event: KeyboardEvent) => this.handlePinKeyDown(event)}
          />
        </div>
        <div class="pin-actions">
          <button type="button" class="pin-verify" aria-label=${this.pinPending ? "Verifying PIN" : "Verify PIN"}
            ?disabled=${this.pinPending || this.pin.length !== 4 || exhausted}
            @click=${() => this.requestPinSubmission()}
          >
            ${this.pinPending ? html`<span class="spinner" role="status" aria-label="Verifying PIN"></span>` : "Verify & Pair"}
          </button>
          ${
            snapshot.pinError && !this.pinPending
              ? html`<span class=${`pill ${attemptsLeft <= 1 ? "bad" : "warn"}`} role="status">
                  <span class="pill-dot"></span>
                  <span>${snapshot.pinError}${exhausted ? "" : ` · ${attemptsLeft} attempt${attemptsLeft === 1 ? "" : "s"} remaining`}</span>
                </span>`
              : html`<span class="muted">The PIN confirms both screens belong to you.</span>`
          }
          ${this.interactionError ? html`<span class="error">${this.interactionError}</span>` : ""}
        </div>
        ${this.renderPinFallback(snapshot)}
      </div>`,
    );
  }

  /**
   * The PIN is only readable on the wallet's own screen, so a wallet that slipped into the
   * background strands this stage exactly like the review stage. Same two escapes, laid out inline
   * because the PIN cells already own the width: Open first, QR behind a toggle.
   */
  private renderPinFallback(snapshot: IMobileBridgeSnapshot) {
    if (snapshot.deepLink == null) return "";
    if (this.walletPlatform === "extension" || this.hideQrOnMobile) return this.renderFallbackSlot(snapshot);
    return html`<div class="stage-fallback">
      <div class="stage-fallback-row">
        ${this.canOpenWalletOnDevice ? html`<button type="button" class="ghost" @click=${() => this.openMobileApp()}>
          Open ${this.walletLabel}
        </button>` : ""}
        <button
          type="button"
          class="ghost"
          aria-pressed=${this.pinQrOpen ? "true" : "false"}
          @click=${() => (this.pinQrOpen = !this.pinQrOpen)}
        >
          ${this.pinQrOpen ? "Hide QR" : "Show QR"}
        </button>
      </div>
      ${
        this.pinQrOpen
          ? html`<div class="qr-frame"><div id="mobile-bridge-qr" class="qr" role="img" aria-label="Scan with ${this.walletLabel}"></div></div>`
          : ""
      }
    </div>`;
  }

  /** Compact icon stage for terminal and transient whole-panel states. */
  private renderStatusStage(
    key: string,
    icon: "check" | "cross" | "spinner",
    tone: "good" | "neutral" | "bad",
    title: string,
    subtitle?: string,
    /** The untouched original error message — searchable fine print, never the headline. */
    fineprint?: string,
    /** The failure card's own control (Try Again), below its description. */
    action?: unknown,
  ) {
    if (tone === "bad") {
      const heading = title === "Something failed in the session flow" || title === "The request could not be completed."
        ? "Something Went Wrong" : title;
      return keyed(key, html`<div class="error-card" role="alert" aria-label="${this.walletLabel} request status">
        <img class="warning-asset" src=${meteorWarning} alt="" />
        <h2>${heading}</h2>
        ${subtitle ? html`<p class="error-description">${subtitle}</p>` : ""}
        ${fineprint ? html`<div class="error-message"><p>${fineprint}</p></div>` : ""}
        ${action ?? ""}
      </div>`);
    }
    return keyed(
      key,
      html`<div class="stage compact">
        <span class="stage-kicker">${this.walletLabel}</span>
        ${
          icon === "spinner"
            ? html`<div class="stage-icon small" aria-hidden="true"><span class="mini-loader"></span></div>`
            : html`<div class=${`stage-icon small ${tone === "good" ? "good" : "neutral"}`} aria-hidden="true">
                ${
                  icon === "check"
                    ? html`<svg viewBox="0 0 24 24"><path d="m5 12.5 4.2 4.2L19 7" /></svg>`
                    : html`<svg viewBox="0 0 24 24"><path d="m6.5 6.5 11 11" /><path d="m17.5 6.5-11 11" /></svg>`
                }
              </div>`
        }
        <h2 class="review-title" style="font-size: calc(1.02rem - var(--mc-font-size-reduction, 0px)); line-height: var(--mc-line-height, 1.2rem);">${title}</h2>
        ${subtitle ? html`<p class="review-subtitle">${subtitle}</p>` : ""}
        ${fineprint ? html`<p class="fineprint">${fineprint}</p>` : ""}
      </div>`,
    );
  }

  private renderIdentityReset() {
    return html`<div class="stage compact">
      <span class="stage-kicker">${this.walletLabel}</span>
      <div class="stage-icon small neutral" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M12 8v5" /><path d="M12 16.6v.1" /><path d="M10.3 3.8 2.9 17a2 2 0 0 0 1.7 3h14.8a2 2 0 0 0 1.7-3L13.7 3.8a2 2 0 0 0-3.4 0" /></svg>
      </div>
      <div class="reset-card">
        <span class="error">This dApp's saved ${this.walletLabel} pairing no longer matches the server.</span>
        ${
          this.resetConfirmation
            ? html`<span class="muted">Resetting removes this dApp's saved wallet pairings for this environment. Your NEAR accounts remain listed and will pair again ${this.walletPlatform === "extension" ? "when you open the extension" : "by QR"}.</span>`
            : ""
        }
        <button ?disabled=${this.resetPending} @click=${() => void this.confirmIdentityReset()}>
          ${this.resetPending ? html`<span class="spinner" role="status" aria-label="Resetting"></span>` : this.resetConfirmation ? "Confirm Reset & Re-pair" : "Reset Wallet Pairing"}
        </button>
        ${this.interactionError ? html`<span class="error">${this.interactionError}</span>` : ""}
      </div>
    </div>`;
  }

  /**
   * States where the stage itself would only be noise, so the shared continuation shows a neutral
   * busy state instead:
   * - `finishing`: the wallet answered (`result_ready`) or the turn is done (`completed`). The
   *   action resolves and the popup closes on its own — there is nothing left to tell the user.
   * - `resuming`: the request was handed to the wallet and the user came back to a tab whose
   *   socket dropped in the background. Until the SDK's redial ladder is live again the honest
   *   state is "checking"; a redial counter and an Open button would only send them back to a
   *   request they may already have answered.
   * `offline` (the ladder gave up) is deliberately not covered — it keeps its Reconnect control.
   */
  private busyPresentation(snapshot: IMobileBridgeSnapshot): "finishing" | "resuming" | undefined {
    if (!this.connectDesign) return undefined;
    if (snapshot.phase === "result_ready" || snapshot.phase === "completed") return "finishing";
    if (
      snapshot.handedOff === true &&
      snapshot.linkPhase === "reconnecting" &&
      RESUMABLE_PHASES.includes(snapshot.phase)
    ) {
      return "resuming";
    }
    return undefined;
  }

  private renderBusy(presentation: "finishing" | "resuming") {
    return html`<meteor-wallet-continuation
      .walletLabel=${this.walletLabel} .walletPlatform=${this.walletPlatform}
      .busy=${
        presentation === "finishing"
          ? { title: "Finishing up", message: `Completing your request with ${this.walletLabel}…` }
          : { title: "Checking request status", message: `Getting the latest from ${this.walletLabel}…` }
      }></meteor-wallet-continuation>`;
  }

  private renderContinuation(snapshot?: IMobileBridgeSnapshot, secondsLeft?: number) {
    const preparing = snapshot?.deepLink == null || ["initializing", "creating_bridge", "busy_other_tab"].includes(snapshot.phase);
    const scanMobile = this.walletPlatform === "mobile" && !isMobile();
    return html`<meteor-wallet-continuation
      .walletLabel=${this.walletLabel} .walletPlatform=${this.walletPlatform}
      .preparing=${preparing} .scanMobile=${scanMobile}
      .instruction=${snapshot?.phase === "wallet_confirmation" && this.walletPlatform !== "mobile" ? this.statusText(snapshot) : undefined}
      .onOpen=${scanMobile ? undefined : () => this.openMobileApp()}>
      ${scanMobile && !preparing ? html`<div slot="visual" class="qr-frame continuation-qr"><div id="mobile-bridge-qr" class="qr" role="img" aria-label="Scan with ${this.walletLabel}"></div></div>` : ""}
      <span slot="countdown">${this.renderCountdown(secondsLeft, "Session expires in")}</span>
      ${snapshot ? this.renderLinkStatus(snapshot) : ""}
      ${this.interactionError ? html`<p role="alert">${this.interactionError}</p>` : ""}
    </meteor-wallet-continuation>`;
  }

  render() {
    const snapshot = this.snapshot;
    if (this.continuation && snapshot == null) return this.renderContinuation();
    if (this.connectDesign && !this.hideQrOnMobile && !this.contextual && (snapshot == null || ["initializing", "creating_bridge", "busy_other_tab"].includes(snapshot.phase))) {
      return html`<section class="panel qr-loading" aria-live="polite" aria-busy="true">
        <div class="heading"><p class="status">${scanHeading}</p></div>
        <div class="request-access">
          <div class="qr-frame loading-frame"><div class="qr loading-placeholder"><span class="spinner" aria-hidden="true"></span></div></div>
          <div class="request-controls"><div class="actions"></div><span class="loading-copy qr-status">Generating secure QR code …</span></div>
        </div>
      </section>`;
    }
    if (snapshot == null) {
      return this.contextual
        ? html`<section class="panel stage-panel" aria-live="polite" aria-label="${this.walletLabel}">${this.renderPushStage(undefined, "sending")}</section>`
        : html`<section class="panel" aria-live="polite">
            <div class="heading">
              <span class="title">${this.walletLabel}</span>
              <div class="status-line"><span class="mini-loader" aria-hidden="true"></span><span>Preparing secure connection…</span></div>
            </div>
          </section>`;
    }
    const mobile = isMobile();
    // The ticker follows the IDLE deadline — the one a successful transition (or a refreshed code)
    // pushes out. The absolute deadline is the wall nothing moves, so once it is STRICTLY the
    // binding one the copy has to stop promising that a refresh buys more time. A tie (a backend
    // that issues equal idle and absolute deadlines at creation) keeps the idle presentation:
    // "Refresh code" tears the session down and mints a whole new one, so a new code genuinely
    // does extend the wait.
    const idleSecondsLeft =
      snapshot.idleExpiresAt == null
        ? undefined
        : Math.max(0, Math.ceil((snapshot.idleExpiresAt - this.now) / 1000));
    const hardStopSecondsLeft =
      snapshot.absoluteExpiresAt == null
        ? undefined
        : Math.max(0, Math.ceil((snapshot.absoluteExpiresAt - this.now) / 1000));
    const hardStopBinding =
      hardStopSecondsLeft != null &&
      (idleSecondsLeft == null || hardStopSecondsLeft < idleSecondsLeft);
    const secondsLeft = hardStopBinding ? hardStopSecondsLeft : idleSecondsLeft;
    const liveFooter = this.renderLiveFooter(snapshot);
    const stagePanelClass = `panel stage-panel${liveFooter === "" && this.interactionError == null ? "" : " auto"}`;
    const showRequestAccess = snapshot.deepLink != null && snapshot.phase === "waiting_for_wallet";
    const showRequestQr = showRequestAccess && !this.hideQrOnMobile && this.showQr && this.walletPlatform !== "extension";
    const inPushPresentation =
      this.contextual &&
      snapshot.push !== "not_attempted" &&
      snapshot.push !== "not_delivered" &&
      ["initializing", "creating_bridge", "waiting_for_wallet", "wallet_action"].includes(
        snapshot.phase,
      ) &&
      this.presentedPushStage !== "review";

    if (snapshot.identityResetRequired) {
      return html`<section class="panel stage-panel slim" aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderIdentityReset()}
      </section>`;
    }

    const busy = this.busyPresentation(snapshot);
    if (busy != null) return this.renderBusy(busy);

    if (this.continuation && ["initializing", "creating_bridge", "busy_other_tab", "waiting_for_wallet", "wallet_confirmation", "wallet_action"].includes(snapshot.phase)) {
      return this.renderContinuation(snapshot, secondsLeft);
    }

    if (inPushPresentation) {
      return html`<section class=${stagePanelClass} aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderPushStage(
          snapshot,
          this.presentedPushStage === "sending" ? "sending" : "sent",
          secondsLeft,
        )}
        ${liveFooter}
      </section>`;
    }

    if (snapshot.phase === "wallet_confirmation") {
      // Keep the mobile session accessible while the wallet handles first-time approval.
      if (this.walletPlatform === "mobile") return this.renderContinuation(snapshot, secondsLeft);
      return html`<section class=${stagePanelClass} aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderStatusStage("partner-confirmation", "spinner", "neutral", `Confirm link in ${this.walletLabel}`, this.statusText(snapshot))}
        ${this.renderCountdown(secondsLeft, "Session expires in")}
        ${this.renderLinkStatus(snapshot)}
        ${liveFooter}
      </section>`;
    }

    if (snapshot.phase === "wallet_verification") {
      return html`<section class="panel stage-panel auto" aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderPinStage(snapshot)}
        ${liveFooter}
      </section>`;
    }

    if (snapshot.phase === "wallet_action") {
      return html`<section class=${stagePanelClass} aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderReviewStage(snapshot, secondsLeft)}
        ${liveFooter}
      </section>`;
    }

    if (
      this.contextual &&
      snapshot.push === "not_delivered" &&
      ["creating_bridge", "waiting_for_wallet"].includes(snapshot.phase)
    ) {
      return html`<section class=${stagePanelClass} aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderPushStage(snapshot, "unavailable", secondsLeft)}
        ${liveFooter}
      </section>`;
    }

    if (snapshot.phase === "completed") {
      return html`<section class="panel stage-panel slim" aria-live="polite" aria-label="${this.walletLabel}">
        ${this.renderStatusStage("mobile-completed", "check", "good", `Completed in ${this.walletLabel}`, "You can continue in this dApp.")}
      </section>`;
    }

    if (snapshot.phase === "failed" || snapshot.phase === "cancelled") {
      // No wallet took part, so nothing is lost by starting over: say so in the user's terms and
      // offer exactly that, instead of the classifier's integrator-facing copy.
      const retryableFailure = mobileBridgeRetryableFailure(snapshot);
      if (retryableFailure != null) {
        const copy = this.retryableFailureCopy(retryableFailure);
        return html`<section class="panel stage-panel slim error-panel" aria-label="${this.walletLabel}">
          ${this.renderStatusStage(
            `mobile-${retryableFailure}`,
            "cross",
            "bad",
            copy.title,
            copy.description,
            undefined,
            this.renderRetryAction(),
          )}
        </section>`;
      }
      // The classifier already produced the copy (headline/detail); the branches left are matched
      // by typed id / kind, never by message: the one id with a remedy of its own, and the
      // backend-connection kind, whose classifier detail is written for the integrator (it names
      // dev servers and firewalls) and so stays out of the user's card. That card is reached only
      // when the mobile bridge is the user's way through — while another wallet is on offer the
      // container leaves the mobile option out quietly instead (`isMobileBridgeQuietlyUnavailable`).
      const walletUpdateRequired =
        snapshot.errorIds?.includes(EErr_Bridge_Session.wallet_update_required) === true;
      const backendUnreachable = snapshot.errorKind === "connection";
      return html`<section class="panel stage-panel slim error-panel" aria-label="${this.walletLabel}">
        ${this.renderStatusStage(
          `mobile-${snapshot.phase}`,
          "cross",
          "bad",
          walletUpdateRequired
            ? `Update ${this.walletLabel} to continue`
            : backendUnreachable
              ? `${this.walletLabel} can’t be reached right now`
              : (snapshot.errorHeadline ?? this.statusText(snapshot)),
          walletUpdateRequired
            ? `This request needs a newer ${this.walletLabel} than the one that answered it.`
            : backendUnreachable
              ? "The Meteor Connect service did not respond. Check your connection and try again in a moment."
              : snapshot.errorDetail,
          snapshot.error,
        )}
      </section>`;
    }

    // `showRequestAccess` is true only in `waiting_for_wallet`, where the close verb is
    // `close_session` — no note, no confirmation step. That is what lets it sit in the controls
    // column beside the code instead of claiming a row of its own underneath, and that row is
    // most of the height the code needs to be scannable.
    const closeControl = this.renderCloseControl(snapshot);

    return html`
      <section class="panel" aria-live="polite" aria-label="${this.walletLabel}">
        <div class="heading">
          <span class="title">${this.walletLabel}</span>
          <p class="status">${this.connectDesign && showRequestAccess ? (this.hideQrOnMobile ? "Continue in Meteor Mobile" : scanHeading) : this.statusText(snapshot)}</p>
        </div>
        ${this.renderLinkStatus(snapshot)}
        ${showRequestAccess && snapshot.push === "delivered" ? html`<span class="pill good"><span class="pill-dot"></span><span>${this.walletPlatform === "extension" ? "Notification sent — open the extension to continue" : "Notification sent — QR remains available"}</span></span>` : ""}
        ${showRequestAccess && snapshot.push === "not_delivered" ? html`<span class="pill warn"><span class="pill-dot"></span><span>${this.walletPlatform === "extension" ? "Notification unavailable — open the extension to continue" : "Notification unavailable — use the code below"}</span></span>` : ""}
        ${
          showRequestAccess
            ? html`
          <div class=${`request-access${mobile && showRequestQr ? " stacked" : ""}`}>
            ${showRequestQr ? html`<div class="qr-frame"><div id="mobile-bridge-qr" class="qr" role="img" aria-label="Scan with ${this.walletLabel}"></div></div>` : ""}
            <div class="request-controls">
              <div class="actions">
                ${this.canOpenWalletOnDevice ? html`<button @click=${() => this.openMobileApp()}>Open ${this.walletLabel}</button>` : ""}
                ${
                  mobile && !this.hideQrOnMobile && this.walletPlatform !== "extension"
                    ? html`<button class="secondary icon-toggle" aria-label=${this.showQr ? "Hide QR code" : "Show QR code"}
                        aria-pressed=${this.showQr ? "true" : "false"}
                        @click=${() => (this.showQr = !this.showQr)}>${svg_qr_glyph}</button>`
                    : ""
                }
              </div>
              ${this.renderCountdown(secondsLeft, hardStopBinding ? "Request expires in" : "Code expires in")}
              ${
                hardStopBinding
                  ? html`<span class="muted">This request has reached its maximum lifetime — a new code cannot extend it.</span>`
                  : !this.connectDesign && secondsLeft != null && secondsLeft <= 60
                    ? html`<button class="ghost" @click=${() => void this.refreshMobileCode()}>Refresh code</button>`
                    : ""
              }
              ${closeControl}
            </div>
          </div>`
            : ""
        }
        ${this.interactionError ? html`<span class="error">${this.interactionError}</span>` : ""}
        ${
          snapshot.errorHeadline == null
            ? ""
            : html`<span class="error">${snapshot.errorHeadline}</span>
                ${snapshot.errorDetail ? html`<span class="muted">${snapshot.errorDetail}</span>` : ""}
                ${snapshot.error ? html`<span class="fineprint">${snapshot.error}</span>` : ""}`
        }
        ${showRequestAccess ? "" : closeControl}
      </section>
    `;
  }
}
