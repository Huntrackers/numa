import { PublicKey } from "@near-js/crypto";
import type { KeyStore } from "@near-js/keystores";
import { MeteorWallet } from "../../../MeteorWallet";
import { convertOldFunctionCallKeyDefToNew } from "../../../near_utils/convertOldFunctionCallKeyDefToNew";
import type { TMeteorSdkV1Transaction } from "../../../ported_common/dapp/dapp.types";
import type { TMCActionOutput, TMCActionRegistry } from "../../action/mc_action.combined";
import type { TMCActionRequestUnionExpandedInput } from "../../action/mc_action.types";
import { supportsChromeExtension } from "../../action_ui/utils/supportsChromeExtension";
import { MeteorLogger } from "../../logging/MeteorLogger";
import type {
  TMeteorConnectAccountNetwork,
  TMeteorConnectionExecutionTarget,
  TMeteorConnectPublicKey,
  TMeteorExecutionTargetConfig,
} from "../../MeteorConnect.types.ts";
import { isV1ExtensionWithDirectAvailable } from "../../utils/isV1ExtensionAvailable";
import { MeteorConnectClientBase } from "../base/MeteorConnectClientBase";
import type { TMeteorConnectV1ExecutionTargetConfig } from "./MeteorConnectV1Client.types";
import { getExtensionSupportedFeatures } from "./utils/getExtensionSupportedFeatures";
import { nearActionToSdkV1Action } from "./utils/nearActionToSdkV1Action";
import type { Action as MeteorNativeAction } from "../../../near_utils/actionCreator/actions";
import { PublicKey as CustomPublicKey } from "../../../near_utils/actionCreator/public_key";
import type { Action as SdkV1Action } from "../../../near_utils/wallet_selector_actions.types";

interface IMeteorWalletV1AndKeyStore {
  wallet: MeteorWallet;
  keyStore: KeyStore;
}

function createKeyForNetworkAndTarget(
  network: TMeteorConnectAccountNetwork,
  target: "v1_web" | "v1_web_localhost" | "v1_ext",
): `${TMeteorConnectAccountNetwork}::${"v1_web" | "v1_web_localhost" | "v1_ext"}` {
  return `${network}::${target}`;
}

export class MeteorConnectV1Client extends MeteorConnectClientBase {
  clientName = "MeteorConnect V1 Client";
  executionTargets: TMeteorConnectionExecutionTarget[] = ["v1_web", "v1_web_localhost", "v1_ext"];
  protected logger = MeteorLogger.createLogger("MeteorConnect:V1Client");
  private readonly sdkForNetworkAndTarget = new Map<string, IMeteorWalletV1AndKeyStore>();

  private getSdkForNetworkAndTarget(
    network: TMeteorConnectAccountNetwork,
    executionTargetConfig: TMeteorConnectV1ExecutionTargetConfig,
  ): IMeteorWalletV1AndKeyStore {
    const key = createKeyForNetworkAndTarget(network, executionTargetConfig.executionTarget);

    const cached = this.sdkForNetworkAndTarget.get(key);
    if (cached != null) {
      this.logger.log(`Using cached SDK for key ${key}`);
      return cached;
    }

    const keyStore = this.meteorConnect.nearKeyStoreProvider.getKeyStore();

    const wallet = new MeteorWallet({
      networkId: network,
      keyStore,
      forceTargetPlatformConfig: executionTargetConfig,
      meteorConnect: this.meteorConnect,
    });

    const created = {
      wallet,
      keyStore,
    };
    this.sdkForNetworkAndTarget.set(key, created);

    return created;
  }

  async getEnvironmentSupportedPlatforms(): Promise<TMeteorConnectionExecutionTarget[]> {
    if (supportsChromeExtension()) {
      return ["v1_ext", "v1_web"];
    }

    return ["v1_web"];
  }

  async getExecutionTargetConfigs<R extends TMCActionRequestUnionExpandedInput<TMCActionRegistry>>(
    _request: R,
  ): Promise<TMeteorExecutionTargetConfig[]> {
    // The V1 wallets only implement the NEAR action domain — offering targets for other domains
    // would fail later in makeRequest's id chain instead of at target selection.
    if (!_request.id.startsWith("near::")) return [];

    const supportedTargets: TMeteorExecutionTargetConfig[] = [
      {
        executionTarget: "v1_web",
      },
    ];

    const forceDev = (await this.meteorConnect.storage.getJsonOrDef("dev_000_met", 0)) === 1;

    if (forceDev || process.env.NODE_ENV === "development") {
      supportedTargets.push({
        executionTarget: "v1_web_localhost",
        // Only use this specific localhost base URL in dev mode for security reasons
        baseUrl: forceDev
          ? "https://localhost:3001"
          : await this.meteorConnect.storage.getJsonOrDef(
              "webDevLocalhostBaseUrl",
              "https://localhost:3001",
            ),
      });
    }

    if (isV1ExtensionWithDirectAvailable()) {
      if (_request.id === "near::sign_in_and_sign_message") {
        const features = await getExtensionSupportedFeatures();

        this.logger.log(`Extension supported features: ${features.join(", ")}`);

        if (features.includes(_request.id)) {
          supportedTargets.push({
            executionTarget: "v1_ext",
          });
        }
      } else {
        supportedTargets.push({
          executionTarget: "v1_ext",
        });
      }
    }

    return supportedTargets;
  }

  async makeRequest<R extends TMCActionRequestUnionExpandedInput<TMCActionRegistry>>(
    request: R,
    connectionConfig: TMeteorExecutionTargetConfig,
  ): Promise<TMCActionOutput<R>> {
    const executionTarget = connectionConfig.executionTarget;
    this.logger.log(
      `Making request for action [${request.id}] using execution target [${executionTarget}]`,
      request.expandedInput,
    );

    if (
      executionTarget !== "v1_web" &&
      executionTarget !== "v1_ext" &&
      executionTarget !== "v1_web_localhost"
    ) {
      throw new Error(
        this.logger.formatMsg(
          `Can't target environment [${executionTarget}] using [${this.clientName}] client`,
        ),
      );
    }

    if (request.id === "near::sign_in" || request.id === "near::sign_in_and_sign_message") {
      const { wallet } = this.getSdkForNetworkAndTarget(
        request.expandedInput.target.network,
        connectionConfig,
      );

      let addFunctionCallKey = request.expandedInput.addFunctionCallKey;

      if (addFunctionCallKey == null && request.expandedInput.contract != null) {
        addFunctionCallKey = convertOldFunctionCallKeyDefToNew({
          contractId: request.expandedInput.contract.id,
          methodNames: request.expandedInput.contract.methods,
        });
      }

      const response = await wallet.requestSignIn({
        addFunctionCallKey: addFunctionCallKey,
        messageParams:
          request.id === "near::sign_in_and_sign_message"
            ? request.expandedInput.messageParams
            : undefined,
      });

      if (response.success) {
        const signedInAccount = response.payload;

        const addedPublicKey = signedInAccount.accessKey?.getPublicKey().toString();

        const publicKeys: TMeteorConnectPublicKey[] = [];

        if (addedPublicKey) {
          publicKeys.push({
            type: "ed25519",
            publicKey: addedPublicKey,
            meta: {
              addFunctionCallKey,
            },
          });
        }

        let signedMessage:
          | TMCActionOutput<Extract<R, { id: "near::sign_in_and_sign_message" }>>["signedMessage"]
          | undefined;

        if (request.id === "near::sign_in_and_sign_message") {
          if (response.payload.signedMessage == null) {
            throw new Error(
              this.logger.formatMsg(
                `Expected signed message in response payload for action [${request.id}] but it was not present`,
              ),
            );
          }

          signedMessage = {
            accountId: response.payload.accountId,
            publicKey: CustomPublicKey.fromString(response.payload.signedMessage.publicKey) as PublicKey,
            signature: Buffer.from(response.payload.signedMessage.signature, "base64"),
            state: response.payload.signedMessage.state,
          };
        }

        return {
          connection: connectionConfig,
          identifier: {
            accountId: signedInAccount.accountId,
            ...request.expandedInput.target,
          },
          publicKeys,
          signedMessage,
        };
      } else {
        throw new Error(`MeteorConnectV1Client: Sign in failed ${response.message}`);
      }
    }

    if (request.id === "near::sign_out") {
      if (
        request.expandedInput.account.publicKeys == null ||
        request.expandedInput.account.publicKeys.length === 0
      ) {
        return request.expandedInput.account.identifier;
      }

      const { wallet } = this.getSdkForNetworkAndTarget(
        request.expandedInput.account.identifier.network,
        connectionConfig,
      );

      await wallet.signOut({
        accountIdentifier: request.expandedInput.account.identifier,
        functionCallKey: request.expandedInput.account.publicKeys[0]?.meta?.addFunctionCallKey,
      });
      return request.expandedInput.account.identifier;
    }

    if (request.id === "near::sign_message") {
      const { wallet } = this.getSdkForNetworkAndTarget(
        request.expandedInput.account.identifier.network,
        connectionConfig,
      );
      const response = await wallet.signMessage({
        ...request.expandedInput.messageParams,
        accountIdentifier: request.expandedInput.account.identifier,
      });

      if (response.success) {
        const payload = {
          accountId: response.payload.accountId,
          publicKey: CustomPublicKey.fromString(response.payload.publicKey) as PublicKey,
          signature: Buffer.from(response.payload.signature, "base64"),
          state: response.payload.state,
        };

        this.logger.log(`Sign message successful for account ${payload.accountId}`, payload);

        return payload;
      } else {
        throw new Error(this.logger.formatMsg(`Sign message failed ${response.message}`));
      }
    }

    if (request.id === "near::sign_transactions") {
      const { wallet } = this.getSdkForNetworkAndTarget(
        request.expandedInput.account.identifier.network,
        connectionConfig,
      );

      return await wallet.requestSignTransactions({
        transactions: request.expandedInput.transactions.map((t): TMeteorSdkV1Transaction => {
          return {
            receiverId: t.receiverId,
            actions: t.actions.map((action) =>
              nearActionToSdkV1Action(action as MeteorNativeAction),
            ),
          };
        }),
        account: request.expandedInput.account,
      });
    }

    if (request.id === "near::verify_owner") {
      const { wallet } = this.getSdkForNetworkAndTarget(
        request.expandedInput.account.identifier.network,
        connectionConfig,
      );

      const response = await wallet.verifyOwner({
        accountIdentifier: request.expandedInput.account.identifier,
        message: request.expandedInput.message,
      });

      if (response.success) {
        return response.payload;
      } else {
        throw new Error(this.logger.formatMsg(`Verify owner failed ${response.message}`));
      }
    }

    if (request.id === "near::sign_delegate_actions") {
      const { wallet } = this.getSdkForNetworkAndTarget(
        request.expandedInput.account.identifier.network,
        connectionConfig,
      );

      return await wallet.requestSignDelegateActions({
        delegateActions: request.expandedInput.delegateActions,
        account: request.expandedInput.account,
      });
    }

    throw new Error(`MeteorConnectV1Client: Action ID [${request["id"]}] not implemented`);
  }
}
