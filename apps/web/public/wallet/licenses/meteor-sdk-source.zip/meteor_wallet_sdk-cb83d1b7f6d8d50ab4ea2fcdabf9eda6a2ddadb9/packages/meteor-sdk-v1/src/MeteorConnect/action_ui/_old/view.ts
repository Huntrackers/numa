/*
import { METEOR_ACTION_UI_CONTAINER_CLASS } from "./action_ui.static";
import { meteorPopupStyles } from "./meteorPopupStyles";

export const head = /!* html *!/ `
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://rsms.me/" />
    <link rel="preconnect" href="https://fonts.cdnfonts.com/" />
    <link rel="stylesheet" href="https://rsms.me/inter/inter.css" />
    <link
      rel="stylesheet"
      href="https://fonts.cdnfonts.com/css/cabinet-grotesk"
    />
    <style>${meteorPopupStyles}</style>
    <title>Meteor Connector</title>
`;

export const bodyMobile = /!* html *!/ `
    <div class="${METEOR_ACTION_UI_CONTAINER_CLASS}">
      <h2 class="title">Approve in <span>App</span></h2>

      <div style="display: flex; gap: 12px;">
        <button class="button" style="white-space: nowrap; width: 140px; margin-top: 16px; margin-bottom: 32px" onclick="window.openMobileDeepLink()">
           Open Mobile
        </button>
      </div>

      <p class="text">
        Don’t have a wallet?<br />
        <a target="_blank" href="https://meteorwallet.app">Get App • iOS • Android</a>
      </p>
    </div>
`;

export const bodyDesktop = /!* html *!/ `
    <div class="${METEOR_ACTION_UI_CONTAINER_CLASS}">
      <h1 class="title" style="margin-bottom: 14px">
        <span>Meteor Wallet</span>
      </h1>
      
      <div style="display: flex; gap: 12px;">
        <button class="button" style="width: 240px; margin-top: 16px; margin-bottom: 32px" onclick="window.openMeteorWeb()">
           Web App
        </button>
      </div>

      <h2 class="divider">OR</h2>
      <h2 class="title">Approve in <span>App</span></h2>

      <div style="display: flex; gap: 12px;">
        <button class="button" style="width: 240px; margin-top: 16px; margin-bottom: 32px" onclick="window.openMeteorExtension()">
           Extension
        </button>
      </div>
    </div>
`;
*/
