import { describe, expect, it } from "bun:test";
import type {
  ICreatedPartnerSession,
  ICreateSessionInput,
  IPreparedSessionTurn,
  ISessionLinkStatus,
  ISessionResultReceipt,
  TPartnerPairedWallet,
} from "@meteorwallet/connect";
import {
  createMemoryStorageAdapter,
  PartnerSessionClient,
  SessionResourceProfileAmbiguityError,
} from "@meteorwallet/connect";
import {
  act_impl_meteor_wallet_core,
  EBridgeLinkType,
  EMeteorAppId,
  ESessionPhase,
  ESessionResourceProfile,
  EWalletPlatform,
  EWalletProtocolCapability,
  hashNewKeyTransferStartInput,
  type IAddKeyJournalChain,
  type IAddKeySignedTransaction,
  type TNewKeyTransferStartInputV1,
  type TNewKeyTransferStartOutputV1,
  type TNewKeyTransferVerifyActiveInputV1,
  type TNewKeyTransferVerifyActiveOutputV1,
  type TSessionFacts,
} from "@meteorwallet/connect-shared";
import { getActionPolicy } from "@meteorwallet/connect-shared/internal";
import { NewKeyTransferError } from "./new_key_transfer_errors";
import { CEnvironmentStorageAdapter } from "../../ported_common/utils/storage/EnvironmentStorageAdapter";
import type { ILocalStorageInterface } from "../../ported_common/utils/storage/storage.types";
import type { MeteorConnect } from "../MeteorConnect";
import type { IMeteorConnection_V2_BridgeMobile } from "../MeteorConnect.types";
import type { IMobileBridgeExternalWorkHold } from "../target_clients/mobile_bridge/MeteorConnectMobileBridgeClient.types";
import { MobileBridgeSession } from "../target_clients/mobile_bridge/MobileBridgeSession";
import { meteorWalletCoreOutputToSdk } from "../target_clients/mobile_bridge/mobileBridgeOutputToSdk";
import {
  getActionRequiredWalletCapabilities,
  sdkActionToMobileBridge,
} from "../target_clients/mobile_bridge/sdkActionToMobileBridge";
import {
  createSessionClientDoubleBase,
  sessionFactsFor,
} from "../test/test_utils/sessionClientDouble";
import { MeteorConnectNewKeyTransfer } from "./MeteorConnectNewKeyTransfer";

const SOURCE_KEY = "ed25519:4vJ9JU1bJJE96FWSJKvHsmmFADCg4gpZQff4P3bkLKi";
const DESTINATION_KEY = "ed25519:CktRuQ2mttgRGkXJtyksdKHjUdc2C4TgDzyB98oEzy8";
const TRANSACTION_HASH = "GgBaCs3NCBuZN12kCJgAW63ydqohFkHEdfdEXBPzLHq";
const CLIENT_ID = "AAAAAAAAAAAAAAAAAAAAAA";
const SESSION_ID = "BBBBBBBBBBBBBBBBBBBBBB";

const START_INPUT: TNewKeyTransferStartInputV1 = {
  formatVersion: 1,
  clientTransferId: CLIENT_ID,
  accounts: [
    {
      blockchainId: "near",
      networkId: "testnet",
      accountId: "alice.testnet",
      sourcePublicKey: SOURCE_KEY,
    },
  ],
};
const START_OUTPUT: TNewKeyTransferStartOutputV1 = {
  formatVersion: 1,
  clientTransferId: CLIENT_ID,
  transferSessionId: SESSION_ID,
  accounts: [
    {
      blockchainId: "near",
      networkId: "testnet",
      accountId: "alice.testnet",
      ok: true,
      destinationSignerType: "seed_phrase",
      destinationPublicKey: DESTINATION_KEY,
    },
  ],
};
/** A SECOND, unrelated transfer — the one a leftover start-result journal slot would brick. */
const SECOND_CLIENT_ID = "CCCCCCCCCCCCCCCCCCCCCC";
const SECOND_SESSION_ID = "DDDDDDDDDDDDDDDDDDDDDD";
const SECOND_DESTINATION_KEY = "ed25519:cGfHiC6Kgg3FpFZvgwGcswsCRtp4aBP2fzuXRQPizuN";
const SECOND_START_INPUT: TNewKeyTransferStartInputV1 = {
  ...START_INPUT,
  clientTransferId: SECOND_CLIENT_ID,
};
const SECOND_START_OUTPUT: TNewKeyTransferStartOutputV1 = {
  ...START_OUTPUT,
  clientTransferId: SECOND_CLIENT_ID,
  transferSessionId: SECOND_SESSION_ID,
  accounts: [
    {
      blockchainId: "near",
      networkId: "testnet",
      accountId: "alice.testnet",
      ok: true,
      destinationSignerType: "seed_phrase",
      destinationPublicKey: SECOND_DESTINATION_KEY,
    },
  ],
};
const VERIFY_INPUT: TNewKeyTransferVerifyActiveInputV1 = {
  formatVersion: 1,
  transferSessionId: SESSION_ID,
  activations: [
    {
      blockchainId: "near",
      networkId: "testnet",
      accountId: "alice.testnet",
      addKeyTransactionHash: TRANSACTION_HASH,
    },
  ],
};
const VERIFY_OUTPUT: TNewKeyTransferVerifyActiveOutputV1 = {
  formatVersion: 1,
  transferSessionId: SESSION_ID,
  accounts: [
    {
      blockchainId: "near",
      networkId: "testnet",
      accountId: "alice.testnet",
      activation: "secured",
      liveness: "confirmed",
    },
  ],
};
const WALLET_VERIFY_KEY = `ed25519::raw_base64::${Buffer.alloc(32, 5).toString("base64")}` as const;
const WALLET_CONNECTION: IMeteorConnection_V2_BridgeMobile = {
  executionTarget: "v2_bridge_mobile",
  schemaVersion: 1,
  bridgeEnvironmentId: "environment",
  meteorAppId: EMeteorAppId.meteor_wallet_web_dev,
  partnerClientId: "partner-client",
  walletVerifyPublicKey: WALLET_VERIFY_KEY,
};
const PAIRED_WALLET: TPartnerPairedWallet = {
  walletVerifyPublicKey: WALLET_VERIFY_KEY,
  walletExchangePublicKey: `x25519::raw_base64::${Buffer.alloc(32, 7).toString("base64")}`,
  meteorAppId: EMeteorAppId.meteor_wallet_web_dev,
  pairedAt: 1,
  walletProtocolVersion: 2,
  walletCapabilities: [EWalletProtocolCapability.new_key_account_transfer_v1],
};

const startRequestPayload = () =>
  act_impl_meteor_wallet_core.action.new_key_account_transfer_start
    .request(START_INPUT)
    .toJsonObject();
const verifyRequestPayload = () =>
  act_impl_meteor_wallet_core.action.new_key_account_transfer_verify_active
    .request(VERIFY_INPUT)
    .toJsonObject();

describe("new-key mobile bridge receive boundary", () => {
  it("serializes both actions and requires the dedicated capability", async () => {
    for (const request of [
      {
        id: "meteor_wallet_core::new_key_account_transfer_start",
        expandedInput: START_INPUT,
      },
      {
        id: "meteor_wallet_core::new_key_account_transfer_verify_active",
        expandedInput: VERIFY_INPUT,
      },
    ]) {
      const prepared = await sdkActionToMobileBridge(request as never);
      expect(prepared.actionRequest.domain).toBe("meteor_wallet_core");
      expect(getActionRequiredWalletCapabilities(prepared.actionRequest)).toContain(
        EWalletProtocolCapability.new_key_account_transfer_v1,
      );
    }
  });

  it("accepts only signed outputs with the exact requested identity set", async () => {
    // Signature verification, action matching, and the result-envelope binding are all performed
    // by `PartnerSessionClient.waitForValidatedResult` before the SDK sees anything. What this
    // layer still owns — and what is asserted here — is the business-level binding of the output
    // back to the account set the request asked for.
    const prepared = await sdkActionToMobileBridge({
      id: "meteor_wallet_core::new_key_account_transfer_start",
      expandedInput: START_INPUT,
    });
    const valid = act_impl_meteor_wallet_core
      .actionForId("new_key_account_transfer_start")
      .validateOutput(START_OUTPUT);
    expect(meteorWalletCoreOutputToSdk(prepared, valid)).toEqual(START_OUTPUT);

    const wrongSet = act_impl_meteor_wallet_core
      .actionForId("new_key_account_transfer_start")
      .validateOutput({
        ...START_OUTPUT,
        accounts: [{ ...START_OUTPUT.accounts[0], accountId: "bob.testnet" }],
      });
    expect(() => meteorWalletCoreOutputToSdk(prepared, wrongSet)).toThrow();
  });

  it("validates the verify session and requested subset of the signed output", async () => {
    const prepared = await sdkActionToMobileBridge({
      id: "meteor_wallet_core::new_key_account_transfer_verify_active",
      expandedInput: VERIFY_INPUT,
    });
    const output = act_impl_meteor_wallet_core
      .actionForId("new_key_account_transfer_verify_active")
      .validateOutput(VERIFY_OUTPUT);
    expect(meteorWalletCoreOutputToSdk(prepared, output)).toEqual(VERIFY_OUTPUT);
  });
});

describe("new-key session resource profiles", () => {
  it("throws SessionResourceProfileAmbiguityError when verify_active omits the profile", async () => {
    // The real trap, on the real client: the profile is derived from the action policy, and the
    // derivation refuses to guess when the policy permits more than one. This throws before any
    // network call, which is why it is reachable without a backend.
    const client = new PartnerSessionClient({
      backendUrl: "https://bridge.example",
      partnerMetadata: { name: "SDK tests", origin: "web_url::https://example.test" },
      storageAdapter: createMemoryStorageAdapter({ keyPrefix: "sdk_test::" }),
    });
    const attempt = client.createSession({
      initialActionRequest: verifyRequestPayload(),
      meteorAppIds: [EMeteorAppId.meteor_wallet_web_dev],
    });
    await expect(attempt).rejects.toBeInstanceOf(SessionResourceProfileAmbiguityError);
    await attempt.catch((error: unknown) => {
      if (!(error instanceof SessionResourceProfileAmbiguityError)) throw error;
      expect(error.allowedResourceProfiles).toEqual([
        ESessionResourceProfile.single_turn_v1,
        ESessionResourceProfile.external_work_v1,
      ]);
    });
  });

  it("names the one action whose policy permits two profiles — the omission trap", () => {
    // `createSession` derives the profile from the action policy and throws
    // SessionResourceProfileAmbiguityError when more than one is permitted. These are the exact
    // policy sets that make omitting `resourceProfile` legal for start and illegal for verify.
    expect(getActionPolicy(startRequestPayload()).allowedResourceProfiles).toEqual([
      ESessionResourceProfile.external_work_v1,
    ]);
    expect(getActionPolicy(verifyRequestPayload()).allowedResourceProfiles).toEqual([
      ESessionResourceProfile.single_turn_v1,
      ESessionResourceProfile.external_work_v1,
    ]);
  });
});

// -------------------------------------------------------------------------------------------
// Session doubles
// -------------------------------------------------------------------------------------------

/** Result/request hashes are canonical padded base64 of 32 bytes — the journal parses them. */
const hashFor = (seed: number): string => Buffer.alloc(32, seed).toString("base64");

const receiptFor = (sequence: number): ISessionResultReceipt => ({
  bridgeId: "bridge-1",
  sequence,
  turnId: `turn-${sequence}`,
  requestHash: hashFor(sequence * 2),
  resultHash: hashFor(sequence * 2 + 1),
});

interface IBridgeTrace {
  createSessionInputs: ICreateSessionInput[];
  preparedActions: Array<{ sequence: number; priorResultHash: string }>;
  externalWorkHolds: Array<{ receipt: ISessionResultReceipt; journaledResultHash: string }>;
  closedReceipts: ISessionResultReceipt[];
  turnWakes: number;
  events: string[];
}

/**
 * A `PartnerSessionClient`-shaped double covering the two-turn new-key choreography: session
 * creation, the validated-result wait, the external-work hold verb, and `prepareAction` /
 * `submitPreparedAction` / `notifyWalletForCurrentTurn` for the turn that follows it. Every
 * facts-returning verb goes through the shared emission base, so the facts reach subscribers
 * before the verb resolves — exactly as the shipped client publishes them.
 */
function createBridgeDouble(outputs: unknown[]) {
  const trace: IBridgeTrace = {
    createSessionInputs: [],
    preparedActions: [],
    externalWorkHolds: [],
    closedReceipts: [],
    turnWakes: 0,
    events: [],
  };
  let sequence = 0;
  let pairedAtTicks = PAIRED_WALLET.pairedAt;
  // `acceptSessionActionFacts`, mirrored once for every double in this package: a verb publishes
  // the facts it returns from inside its own still-pending await (`createSessionClientDoubleBase`).
  const base = createSessionClientDoubleBase({
    facts: sessionFactsFor(ESessionPhase.waiting_for_wallet),
  });
  const nextOutput = (): unknown => {
    const output = outputs.shift();
    if (output === undefined) throw new Error("no scripted wallet result remains");
    return output;
  };
  const client = {
    backendUrl: "https://bridge.example",
    events: base.events,
    linkStatus: {
      phase: "live",
      attempt: 0,
      retryInMs: undefined,
      lastDownForMs: undefined,
      attachError: undefined,
      diagnostics: {},
    } satisfies ISessionLinkStatus,
    get sessionFacts(): Readonly<TSessionFacts> | undefined {
      return base.getSessionFacts();
    },
    createSession: async (input: ICreateSessionInput): Promise<ICreatedPartnerSession> => {
      trace.createSessionInputs.push({ ...input });
      sequence = 0;
      // The shipped `createSession` binds the session and stages its initial turn, accepting the
      // facts it is about to return along the way — so they are published, not merely returned.
      const facts = base.publishFacts(sessionFactsFor(ESessionPhase.waiting_for_wallet));
      return {
        bridgeId: "bridge-1",
        bridgeLease: "lease-1",
        partnerId: "partner-1",
        partnerRequestId: `sdk-request-${trace.createSessionInputs.length}`,
        partnerSecret: "secret",
        walletLinks: [
          {
            appId: EMeteorAppId.meteor_wallet_web_dev,
            walletName: "Meteor Web Dev",
            walletDescription: "dev",
            platform: EWalletPlatform.web,
            linkString: "https://wallet-dev.meteorwallet.app/bridge_request?linkFormat=s1",
            linkType: EBridgeLinkType.web_app_url,
          },
        ],
        facts,
        initialTurn: { envelope: {}, signatureBase64: "" },
      } as unknown as ICreatedPartnerSession;
    },
    // The session's own claimant (0.13+).
    get claimedWallet(): TPartnerPairedWallet {
      return { ...PAIRED_WALLET, pairedAt: (pairedAtTicks += 1) };
    },
    getPairedWallets: async (): Promise<TPartnerPairedWallet[]> => [
      { ...PAIRED_WALLET, pairedAt: (pairedAtTicks += 1) },
    ],
    notifyWalletForInitialClaim: async () => ({ delivered: true }),
    notifyWalletForCurrentTurn: async () => {
      trace.turnWakes += 1;
      return { delivered: true } as never;
    },
    // The wait itself accepts no facts: the staged result reaches the client through the realm
    // projection, which is where `result_ready` comes from.
    waitForValidatedResult: async () => {
      sequence += 1;
      base.emit("factsChanged", {
        facts: sessionFactsFor(ESessionPhase.result_ready),
        source: "realm",
      });
      return { status: "ok", output: nextOutput(), receipt: receiptFor(sequence) } as never;
    },
    acknowledgeAndClose: base.verb(
      (receipt: ISessionResultReceipt) => {
        trace.events.push("verb:acknowledgeAndClose");
        trace.closedReceipts.push(receipt);
        return sessionFactsFor(ESessionPhase.closed);
      },
      { selfInitiated: true },
    ),
    acknowledgeAndBeginExternalWork: base.verb(
      (receipt: ISessionResultReceipt, journaledResultHash: string) => {
        trace.events.push("verb:acknowledgeAndBeginExternalWork");
        trace.externalWorkHolds.push({ receipt, journaledResultHash });
        return sessionFactsFor(ESessionPhase.external_work);
      },
    ),
    prepareAction: async (input: {
      sequence: number;
      priorResultHash: string;
    }): Promise<IPreparedSessionTurn> => {
      trace.preparedActions.push({
        sequence: input.sequence,
        priorResultHash: input.priorResultHash,
      });
      return { envelope: {}, signatureBase64: "" } as unknown as IPreparedSessionTurn;
    },
    submitPreparedAction: base.verb(() => sessionFactsFor(ESessionPhase.wallet_action)),
    closePhaseSafe: base.verb(() => sessionFactsFor(ESessionPhase.closed), {
      selfInitiated: true,
    }),
    // The client drops the binding's facts here, so a fresh session starts from nothing.
    disconnectBridge: async (): Promise<void> => {
      base.releaseBinding();
    },
  };
  return { client: client as unknown as PartnerSessionClient, trace };
}

function memoryLocalStorage() {
  const values = new Map<string, string>();
  const implementation: ILocalStorageInterface = {
    setItem: async (key, value) => {
      values.set(key, value);
    },
    getItem: async (key) => values.get(key) ?? null,
    removeItem: async (key) => {
      values.delete(key);
    },
  };
  return { values, implementation };
}

/**
 * Drives `MeteorConnectNewKeyTransfer` against a REAL `MobileBridgeSession` over the client double
 * above, standing in for the `ExecutableAction` + `ActionUi` glue only.
 */
function createHarness(input: { sessions?: Map<string, unknown>; outputs?: unknown[] } = {}) {
  const values = input.sessions ?? new Map<string, unknown>();
  const storage = memoryLocalStorage();
  const outputs = input.outputs ?? [START_OUTPUT, VERIFY_OUTPUT];
  const { client, trace } = createBridgeDouble(outputs);
  const targeted: Array<{
    id: string;
    platform?: string;
    walletConnection?: IMeteorConnection_V2_BridgeMobile;
    continuedHold?: IMobileBridgeExternalWorkHold;
    retained: boolean;
  }> = [];
  let heldSession: MobileBridgeSession | undefined;
  let currentSession: MobileBridgeSession | undefined;
  const releasedSessions: MobileBridgeSession[] = [];
  let promptCount = 0;
  /** Total serialized size the typed storage accepts, like a browser's per-origin quota. */
  let jsonQuotaChars = Number.POSITIVE_INFINITY;
  const serializedSizeWithout = (key: string) =>
    [...values].reduce(
      (total, [storedKey, value]) =>
        storedKey === key ? total : total + JSON.stringify(value).length,
      0,
    );

  const meteorConnect = {
    localStorageAdapter: new CEnvironmentStorageAdapter(storage.implementation),
    mobileBridgeClient: {
      getCurrentSession: () => currentSession,
      releaseSession: async (session: MobileBridgeSession) => {
        releasedSessions.push(session);
        if (currentSession === session) currentSession = undefined;
        if (heldSession === session) heldSession = undefined;
        await session.dispose();
      },
    },
    storage: {
      getJson: async (key: string) => values.get(key),
      setJson: async (key: string, value: unknown) => {
        if (serializedSizeWithout(key) + JSON.stringify(value).length > jsonQuotaChars) {
          throw new DOMException(
            `Setting the value of 'met_data_${key}' exceeded the quota.`,
            "QuotaExceededError",
          );
        }
        values.set(key, structuredClone(value));
      },
      removeItem: async (key: string) => {
        values.delete(key);
      },
    },
    createAction: async (request: { id: string; input: Record<string, unknown> }) => {
      let target: {
        platform?: string;
        walletConnection?: IMeteorConnection_V2_BridgeMobile;
        externalWorkJournal?: (input: {
          receipt: ISessionResultReceipt;
          output: unknown;
        }) => Promise<string>;
        continueExternalWorkHold?: IMobileBridgeExternalWorkHold;
        retainSessionForExternalWork?: boolean;
      };
      let session: MobileBridgeSession | undefined;
      return {
        setTransferTarget: (value: typeof target) => {
          target = value;
          targeted.push({
            id: request.id,
            platform: value.platform,
            walletConnection: value.walletConnection,
            continuedHold: value.continueExternalWorkHold,
            retained: value.retainSessionForExternalWork === true,
          });
        },
        getExternalWorkHold: () => session?.getExternalWorkHold(),
        getCompletedMobileConnection: () => session?.getCompletedConnection(),
        getTransferTargetPlatform: () => target?.platform,
        promptForExecution: async () => {
          promptCount += 1;
          // No pinned platform means the popup's chooser picks one before the bridge is
          // prepared (the container calls prepareMobileBridge({ transferTargetPlatform })).
          // The harness stands in for that choice with "web".
          if (target.platform == null) target.platform = "web";
          const pending = values.get("newKeyTransferSessions") as Array<{
            clientTransferId: string;
            phase: string;
          }>;
          const currentClientTransferId =
            typeof request.input.clientTransferId === "string"
              ? request.input.clientTransferId
              : CLIENT_ID;
          expect(
            pending.find((stored) => stored.clientTransferId === currentClientTransferId)?.phase ??
              pending[0]?.phase,
          ).toMatch(/pending|progress/);
          const prepared = await sdkActionToMobileBridge({
            id: request.id,
            expandedInput: request.input,
          } as never);
          const continued = target.continueExternalWorkHold;
          if (continued != null && heldSession?.getExternalWorkHold() != null) {
            session = heldSession;
            await heldSession.beginNextTurn(prepared);
          } else {
            session = new MobileBridgeSession({
              token: `token-${promptCount}`,
              client,
              prepared,
              targetMeteorAppIds: [EMeteorAppId.meteor_wallet_web_dev],
              pushWallet: target.walletConnection == null ? undefined : PAIRED_WALLET,
              pinnedWallet: target.walletConnection == null ? undefined : PAIRED_WALLET,
              journalBeforeExternalWorkHold: target.externalWorkJournal,
              buildConnection: () => WALLET_CONNECTION,
              isCurrent: () => true,
              assertIdentityGeneration: async () => {},
              acquireFirstPairingLease: async () => ({
                ownerToken: "lease",
                assertOwned: async () => {},
                release: async () => {},
              }),
              registerLiveSession: async () => ({ stop: async () => {} }),
            });
            await session.startPreparation();
          }
          currentSession = session;
          const output = await session.awaitResult();
          if (target.retainSessionForExternalWork === true) heldSession = session;
          return output;
        },
      };
    },
  };
  const api = new MeteorConnectNewKeyTransfer(meteorConnect as unknown as MeteorConnect);
  api.configure(true);
  return {
    api,
    trace,
    targeted,
    storage,
    releasedSessions,
    getPromptCount: () => promptCount,
    dropHold: () => {
      heldSession = undefined;
    },
    setStoredSessions: (sessions: unknown) => values.set("newKeyTransferSessions", sessions),
    values,
    /** Fill the typed storage to `used + headroom` serialized characters, like a full origin. */
    setJsonQuotaHeadroom: (headroom: number) => {
      jsonQuotaChars = serializedSizeWithout("") + headroom;
    },
  };
}

/**
 * A chain seam that finalizes immediately. Everything that decides whether the AddKey is
 * authorized still belongs to the shared runner + proof verifier — this only plays the RPC.
 */
interface IChainDoubleOptions {
  /** Whether the destination key is already granted on the account. */
  destinationLive?: boolean;
  /** Whether `getFinalTransactionStatus` can prove the transaction. */
  transactionKnown?: boolean;
  /** `undefined` models a host that cannot answer the expiry question at all. */
  signedTransactionExpired?: boolean;
}

function createChainDouble(options: IChainDoubleOptions = {}): {
  chain: IAddKeyJournalChain;
  calls: string[];
} {
  const calls: string[] = [];
  let destinationLive = options.destinationLive ?? false;
  const signed: IAddKeySignedTransaction = {
    transactionHash: TRANSACTION_HASH,
    signedTransactionBase64: Buffer.alloc(64, 3).toString("base64"),
  };
  const finalStatus = (job: { accountId: string; destinationPublicKey: string }) => ({
    final_execution_status: "FINAL",
    status: { SuccessValue: "" },
    transaction: {
      hash: TRANSACTION_HASH,
      signer_id: job.accountId,
      receiver_id: job.accountId,
      public_key: SOURCE_KEY,
      actions: [
        {
          AddKey: {
            public_key: job.destinationPublicKey,
            access_key: { nonce: 1, permission: "FullAccess" },
          },
        },
      ],
    },
  });
  const chain: IAddKeyJournalChain = {
    getAccessKeys: async (job) => {
      calls.push("getAccessKeys");
      return {
        keys: [
          { public_key: job.sourcePublicKey, access_key: { nonce: 1, permission: "FullAccess" } },
          ...(destinationLive
            ? [
                {
                  public_key: job.destinationPublicKey,
                  access_key: { nonce: 2, permission: "FullAccess" },
                },
              ]
            : []),
        ],
      };
    },
    signAddKeyTransaction: async () => {
      calls.push("sign");
      return signed;
    },
    broadcastSignedTransaction: async (job) => {
      calls.push("broadcast");
      destinationLive = true;
      return finalStatus(job);
    },
    getFinalTransactionStatus: async (job) => {
      calls.push("status");
      if (options.transactionKnown === false) throw new Error("Transaction is not currently known");
      return finalStatus(job);
    },
  };
  if (options.signedTransactionExpired != null) {
    chain.isSignedTransactionExpired = async () => {
      calls.push("expiry");
      return options.signedTransactionExpired === true;
    };
  }
  return { chain, calls };
}

const ADD_KEY_JOURNAL_KEY = "met_data_newKeyTransferAddKeyJournal";
const START_RESULT_JOURNAL_KEY = "met_data_newKeyTransferStartResultJournal";

/**
 * The exact damaged storage state observed during demo development: a signed AddKey row whose
 * start-result record is gone. Resume refuses (nothing binds the operation) and starting a
 * replacement refuses (the global orphan fence) — which is what made affected browser profiles
 * permanently stranded before B-04.
 */
async function strandWithOrphanedSignedAddKey(
  harness: ReturnType<typeof createHarness>,
): Promise<void> {
  await harness.storage.implementation.setItem(
    ADD_KEY_JOURNAL_KEY,
    JSON.stringify({
      formatVersion: 2,
      entries: [
        {
          operationVersion: 1,
          transferSessionId: SESSION_ID,
          blockchainId: "near",
          networkId: "testnet",
          accountId: "alice.testnet",
          sourcePublicKey: SOURCE_KEY,
          destinationPublicKey: DESTINATION_KEY,
          phase: "transaction_signed",
          transactionHash: TRANSACTION_HASH,
          signedTransactionBase64: Buffer.alloc(64, 3).toString("base64"),
        },
      ],
    }),
  );
  await harness.storage.implementation.removeItem(START_RESULT_JOURNAL_KEY);
}

describe("MeteorConnectNewKeyTransfer journal", () => {
  it("persists the extension destination for recovery and verification", async () => {
    const harness = createHarness();
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "extension",
      accounts: START_INPUT.accounts,
    });
    expect((await harness.api.getSessions())[0]?.targetPlatform).toBe("extension");
    const { chain } = createChainDouble();
    const addKeys = await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain });
    await harness.api.verifyActive(addKeys.verifyInput!);
    expect(harness.targeted.map((target) => target.platform)).toEqual(["extension", "extension"]);
  });

  it("commits before prompting, replays once, and rejects changed input under the same id", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    const options = {
      clientTransferId: CLIENT_ID,
      targetPlatform: "web" as const,
      accounts: START_INPUT.accounts,
    };
    const [first, replay] = await Promise.all([
      harness.api.start(options),
      harness.api.start(options),
    ]);
    expect(first.output).toEqual(START_OUTPUT);
    expect(replay.output).toEqual(START_OUTPUT);
    expect(harness.getPromptCount()).toBe(1);
    await expect(
      harness.api.start({
        ...options,
        accounts: [{ ...START_INPUT.accounts[0], accountId: "bob.testnet" }],
      }),
    ).rejects.toThrow("new_key_transfer_client_id_conflict");
  });

  it("records the popup-chosen platform when start omits targetPlatform and replays cleanly", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    const options = { clientTransferId: CLIENT_ID, accounts: START_INPUT.accounts };
    const first = await harness.api.start(options);
    // The harness's prompt simulates the popup chooser answering on "web"; the session must
    // record that choice so the verify turn can pin to it.
    expect(first.session.targetPlatform).toBe("web");
    // A repeat without a pinned platform replays the committed output instead of conflicting
    // with the platform the chooser picked.
    const replay = await harness.api.start(options);
    expect(replay.output).toEqual(START_OUTPUT);
    expect(harness.getPromptCount()).toBe(1);
    // A repeat that pins a DIFFERENT platform than the one chosen is still refused.
    await expect(harness.api.start({ ...options, targetPlatform: "mobile" })).rejects.toThrow(
      "new_key_transfer_client_id_conflict",
    );
  });

  it("serializes different transfers through the shared journal without losing either session", async () => {
    const values = new Map<string, unknown>();
    const firstHarness = createHarness({ sessions: values, outputs: [START_OUTPUT] });
    const secondHarness = createHarness({
      sessions: values,
      outputs: [
        { ...START_OUTPUT, clientTransferId: "C".repeat(22), transferSessionId: "D".repeat(22) },
      ],
    });
    await Promise.all([
      firstHarness.api.start({
        clientTransferId: CLIENT_ID,
        targetPlatform: "web",
        accounts: START_INPUT.accounts,
      }),
      secondHarness.api.start({
        clientTransferId: "C".repeat(22),
        targetPlatform: "mobile",
        accounts: START_INPUT.accounts,
      }),
    ]);
    expect(
      (await firstHarness.api.getSessions()).map((session) => session.clientTransferId).sort(),
    ).toEqual([CLIENT_ID, "C".repeat(22)].sort());
  });

  it("fails closed instead of silently clearing a malformed persisted journal", async () => {
    const harness = createHarness({ outputs: [] });
    harness.setStoredSessions([{ formatVersion: 1, clientTransferId: "bad" }]);
    await expect(harness.api.getSessions()).rejects.toThrow("new_key_transfer_journal_corrupt");

    const strictHarness = createHarness({ outputs: [START_OUTPUT] });
    await strictHarness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    const stored = await strictHarness.api.getSessions();
    (stored[0] as unknown as Record<string, unknown>).unexpected = true;
    strictHarness.setStoredSessions(stored);
    await expect(strictHarness.api.getSessions()).rejects.toThrow(
      "new_key_transfer_journal_corrupt",
    );
  });

  it("pins verify to the start wallet and preserves sessions after AddKey intent", async () => {
    const harness = createHarness();
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await harness.api.markAddKeyIntent({
      transferSessionId: SESSION_ID,
      accounts: START_INPUT.accounts,
    });
    await expect(harness.api.clear(CLIENT_ID)).rejects.toThrow(
      "new_key_transfer_recovery_required",
    );
    const verified = await harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: VERIFY_INPUT.activations,
    });
    expect(verified.session.phase).toBe("destination_keys_verified");
    expect(harness.targeted.at(-1)?.walletConnection).toEqual(WALLET_CONNECTION);
  });

  it("releases the recovery fence only after exact destination-key revocation is acknowledged", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await harness.api.markAddKeyIntent({
      transferSessionId: SESSION_ID,
      accounts: START_INPUT.accounts,
    });

    await expect(
      harness.api.markDestinationKeysRevoked({
        transferSessionId: SESSION_ID,
        accounts: [{ ...START_INPUT.accounts[0], accountId: "bob.testnet" }],
      }),
    ).rejects.toThrow("new_key_transfer_revoke_account_mismatch");

    const revoked = await harness.api.markDestinationKeysRevoked({
      transferSessionId: SESSION_ID,
      accounts: START_INPUT.accounts,
    });
    expect(revoked.phase).toBe("destination_keys_staged");
    expect(revoked.addKeyIntentAccounts).toEqual([]);
    expect(revoked.verifiedAccounts).toEqual([]);
    await expect(harness.api.clear(CLIENT_ID)).resolves.toBeUndefined();
    expect(await harness.api.getSessions()).toEqual([]);
    // Clearing a transfer must not strand its bridge: the held session is closed and released, or
    // every later action would be refused as `mobile_bridge_session_already_active`.
    expect(harness.releasedSessions).toHaveLength(1);
  });

  it("discards the cleared transfer's start result so a later transfer can be started", async () => {
    // The shared AddKey journal has exactly ONE start-result slot and `rememberStartResult`
    // refuses to displace another transfer's, so a start result left behind by `clear()` rejects
    // every LATER transfer with `start_result_conflict` — after the wallet has already minted its
    // destination keys. Both of clear()'s fences have passed here, which is precisely the
    // condition under which discarding is safe.
    const harness = createHarness({ outputs: [START_OUTPUT, SECOND_START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    expect((await harness.api.getRecoveryState()).startResult?.output.transferSessionId).toBe(
      SESSION_ID,
    );

    await harness.api.clear(CLIENT_ID);
    expect((await harness.api.getRecoveryState()).startResult).toBeNull();

    const second = await harness.api.start({
      clientTransferId: SECOND_CLIENT_ID,
      targetPlatform: "web",
      accounts: SECOND_START_INPUT.accounts,
    });
    expect(second.output.transferSessionId).toBe(SECOND_SESSION_ID);
    expect((await harness.api.getRecoveryState()).startResult?.output.transferSessionId).toBe(
      SECOND_SESSION_ID,
    );
  });

  it("keeps the session when the start result cannot be discarded, rather than half-clearing", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    harness.storage.implementation.removeItem = async () => {
      throw new Error("storage unavailable");
    };

    await expect(harness.api.clear(CLIENT_ID)).rejects.toThrow(
      "new_key_transfer_start_result_discard_failed",
    );
    // A session row deleted on top of an undiscardable start result would be unrecoverable: the
    // transfer could no longer be resumed AND no later one could be started.
    expect((await harness.api.getSessions()).map((stored) => stored.clientTransferId)).toEqual([
      CLIENT_ID,
    ]);
  });

  it("never displaces ANOTHER transfer's journaled start result when clearing", async () => {
    // `clear()` owns the transfer it names and nothing else. A start result belonging to a
    // different transfer is live recoverable state — dropping it would strand that transfer's
    // destination keys exactly as the bug above stranded these.
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    // A second transfer that never reached the wallet: journaled sessions carry it, the shared
    // start-result slot still names the first.
    harness.setStoredSessions([
      ...(await harness.api.getSessions()),
      {
        formatVersion: 1,
        phase: "start_pending",
        targetPlatform: "web",
        clientTransferId: SECOND_CLIENT_ID,
        canonicalInputHash: hashNewKeyTransferStartInput(SECOND_START_INPUT),
        startRequest: SECOND_START_INPUT,
        addKeyIntentAccounts: [],
        verifiedAccounts: [],
        updatedAt: Date.now(),
      },
    ]);

    await harness.api.clear(SECOND_CLIENT_ID);

    expect((await harness.api.getRecoveryState()).startResult?.output.transferSessionId).toBe(
      SESSION_ID,
    );
    expect((await harness.api.getSessions()).map((stored) => stored.clientTransferId)).toEqual([
      CLIENT_ID,
    ]);
  });
});

describe("MeteorConnectNewKeyTransfer external-work hold", () => {
  it("journals the signed start result BEFORE beginning the hold, naming its exact hash", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    const started = await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });

    expect(started.externalWorkHeld).toBe(true);
    // The start action's profile is policy-derived (`external_work_v1` is its only one), so the
    // SDK never names it — and never closes the turn either.
    expect(harness.trace.createSessionInputs).toHaveLength(1);
    expect(harness.trace.createSessionInputs[0]?.resourceProfile).toBeUndefined();
    expect(harness.trace.closedReceipts).toHaveLength(0);
    expect(harness.trace.externalWorkHolds).toHaveLength(1);

    const held = harness.trace.externalWorkHolds[0]!;
    expect(held.journaledResultHash).toBe(held.receipt.resultHash);

    // Journal-before-hold: the durable record exists, and it is the record the hold verb named.
    const recovery = await harness.api.getRecoveryState();
    expect(recovery.startResult?.resultHash).toBe(held.receipt.resultHash);
    expect(recovery.startResult?.output).toEqual(START_OUTPUT);
    expect(recovery.orphanedSignedAddKey).toBe(false);
  });

  it("reports no hold when the replaying process is not the one holding it", async () => {
    // The hold is memory-only: it lives in the instance that opened the bridge, never in the
    // journal. A second process replaying the same start therefore gets the SAME signed output
    // back — the wallet is not asked twice — but must be told `externalWorkHeld: false`, because
    // the bridge it would try to continue belongs to someone else. Reporting `true` here would
    // send it down the same-session verification path with no session to verify on.
    const values = new Map<string, unknown>();
    const holder = createHarness({ sessions: values, outputs: [START_OUTPUT] });
    const started = await holder.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    expect(started.externalWorkHeld).toBe(true);

    const other = createHarness({ sessions: values, outputs: [] });
    const replayed = await other.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });

    expect(replayed.output).toEqual(START_OUTPUT);
    expect(other.getPromptCount()).toBe(0);
    expect(replayed.externalWorkHeld).toBe(false);
  });

  it("refuses the hold — and closes the turn — when the journal write fails", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    harness.storage.implementation.setItem = async () => {
      throw new Error("quota exceeded");
    };
    await expect(
      harness.api.start({
        clientTransferId: CLIENT_ID,
        targetPlatform: "web",
        accounts: START_INPUT.accounts,
      }),
    ).rejects.toThrow();
    // No hold may begin without its journal, and the wallet's signed result is never left parked
    // in `result_ready`.
    expect(harness.trace.externalWorkHolds).toHaveLength(0);
    expect(harness.trace.closedReceipts).toHaveLength(1);
  });

  it("runs AddKey through the shared runner and installs verify on the SAME session", async () => {
    const harness = createHarness();
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });

    const { chain, calls } = createChainDouble();
    const addKeys = await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain });
    expect(addKeys.verifyInput).toEqual(VERIFY_INPUT);
    // The runner's own ordering: read the journal, record intent, sign, broadcast — never a
    // replacement transaction after an ambiguous send.
    // The journal is read before the first chain call; intent is durable before signing; the
    // exact signed bytes are durable before broadcast; and finality is re-proven from the chain.
    expect(calls).toEqual(["getAccessKeys", "sign", "broadcast", "getAccessKeys"]);
    expect(addKeys.session.phase).toBe("add_key_in_progress");
    expect(addKeys.session.addKeyIntentAccounts).toEqual(["near::testnet::alice.testnet"]);

    const verified = await harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: addKeys.verifyInput.activations,
    });
    expect(verified.output).toEqual(VERIFY_OUTPUT);
    expect(verified.session.phase).toBe("destination_keys_verified");

    // One session, two turns: the verification turn was prepared against the held receipt, woke
    // the wallet for that turn, and only then was the session closed.
    expect(harness.trace.createSessionInputs).toHaveLength(1);
    expect(harness.trace.preparedActions).toEqual([{ sequence: 2, priorResultHash: hashFor(3) }]);
    expect(harness.trace.turnWakes).toBe(1);
    expect(harness.trace.closedReceipts.map((receipt) => receipt.sequence)).toEqual([2]);
    expect(harness.targeted.at(-1)?.continuedHold?.bridgeId).toBe("bridge-1");

    // The verification proof is durable before the turn is staged and cleared only once verified.
    expect((await harness.api.getRecoveryState()).pendingVerification).toBeNull();
  });

  it("recovers on a FRESH single_turn_v1 session when the hold is lost mid-flight", async () => {
    const harness = createHarness();
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    const { chain } = createChainDouble();
    await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain });

    // Process loss: the memory-only partner secret — and with it the hold — is gone.
    harness.dropHold();
    (
      harness.api as unknown as { externalWorkHolds: Map<string, unknown> }
    ).externalWorkHolds.clear();

    const verified = await harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: VERIFY_INPUT.activations,
    });
    expect(verified.session.phase).toBe("destination_keys_verified");

    // A second, freshly created session — never a replayed lease — carrying the profile the SDK
    // must name explicitly (two are permitted), pinned to the exact wallet that minted the keys.
    expect(harness.trace.createSessionInputs).toHaveLength(2);
    const recovery = harness.trace.createSessionInputs[1]!;
    expect(recovery.resourceProfile).toBe(ESessionResourceProfile.single_turn_v1);
    expect(recovery.partnerRequestId).toBeUndefined();
    expect(recovery.clientConnectionInfo?.walletVerifyPublicKey).toBe(WALLET_VERIFY_KEY);
    expect(harness.trace.preparedActions).toHaveLength(0);
    expect(harness.targeted.at(-1)?.continuedHold).toBeUndefined();
  });

  it("refuses AddKey when the durable start-result journal does not bind this transfer", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    // Lose the start-result record the way a cleared browser store would.
    await harness.storage.implementation.removeItem("met_data_newKeyTransferStartResultJournal");
    const { chain, calls } = createChainDouble();
    await expect(harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain })).rejects.toThrow(
      "new_key_transfer_start_result_journal_missing",
    );
    expect(calls).toEqual([]);
  });
});

describe("MeteorConnectNewKeyTransfer orphaned-AddKey reconciliation (B-04)", () => {
  it("exposes non-secret evidence and a support reference instead of a bare boolean", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await strandWithOrphanedSignedAddKey(harness);

    const recovery = await harness.api.getRecoveryState();
    expect(recovery.orphanedSignedAddKey).toBe(true);
    expect(recovery.reconciliation.fenced).toBe(true);
    expect(recovery.reconciliation.reason).toBe("orphaned_signed_add_key");
    expect(recovery.reconciliation.operations).toEqual([
      {
        transferSessionId: SESSION_ID,
        blockchainId: "near",
        networkId: "testnet",
        accountId: "alice.testnet",
        sourcePublicKey: SOURCE_KEY,
        destinationPublicKey: DESTINATION_KEY,
        phase: "transaction_signed",
        transactionHash: TRANSACTION_HASH,
        hasReplayableSignedTransaction: true,
      },
    ]);
    // A real reference the consumer can render — MNW promised one and had nothing to show.
    expect(recovery.reconciliation.supportReference).toMatch(/^MCNKT(-[A-Z2-7]{4}){4}$/);
    // The replayable bytes stay inside the journal.
    expect(JSON.stringify(recovery.reconciliation)).not.toContain(
      Buffer.alloc(64, 3).toString("base64"),
    );
  });

  it("resolves the fence when the transaction is proven final, and lets the transfer resume", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, VERIFY_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await harness.api.markAddKeyIntent({
      transferSessionId: SESSION_ID,
      accounts: START_INPUT.accounts,
    });
    await strandWithOrphanedSignedAddKey(harness);

    const report = await harness.api.getReconciliationReport();
    const { chain } = createChainDouble({ destinationLive: true });
    const result = await harness.api.reconcileFencedOperation({
      operation: report.operations[0]!,
      chain,
    });
    expect(result.status).toBe("finalized");
    expect(result.transactionHash).toBe(TRANSACTION_HASH);

    // The global fence is lifted, so the host is no longer stuck between "cannot resume" and
    // "cannot start again".
    expect((await harness.api.getReconciliationReport()).fenced).toBe(false);
    const verified = await harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: VERIFY_INPUT.activations,
    });
    expect(verified.session.phase).toBe("destination_keys_verified");
  });

  it("keeps the fence while the signed bytes could still land", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await strandWithOrphanedSignedAddKey(harness);

    const report = await harness.api.getReconciliationReport();
    const { chain } = createChainDouble({
      transactionKnown: false,
      destinationLive: false,
      signedTransactionExpired: false,
    });
    const result = await harness.api.reconcileFencedOperation({
      operation: report.operations[0]!,
      chain,
    });
    expect(result.status).toBe("ambiguous");
    expect(result.detail).toBe("signed_transaction_may_still_land");
    expect((await harness.api.getReconciliationReport()).fenced).toBe(true);
  });

  it("archives a dead operation and releases the fence", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await strandWithOrphanedSignedAddKey(harness);

    const report = await harness.api.getReconciliationReport();
    const { chain } = createChainDouble({
      transactionKnown: false,
      destinationLive: false,
      signedTransactionExpired: true,
    });
    const operation = report.operations[0]!;
    expect((await harness.api.reconcileFencedOperation({ operation, chain })).status).toBe(
      "destination_key_absent",
    );
    expect(await harness.api.archiveReconciledOperation({ operation, chain })).toBe(true);
    expect((await harness.api.getReconciliationReport()).fenced).toBe(false);
  });

  it("refuses to archive while the destination key is still on the account", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await strandWithOrphanedSignedAddKey(harness);

    const report = await harness.api.getReconciliationReport();
    const { chain } = createChainDouble({ transactionKnown: false, destinationLive: true });
    const operation = report.operations[0]!;
    expect((await harness.api.reconcileFencedOperation({ operation, chain })).status).toBe(
      "destination_key_present_unproven",
    );
    expect(await harness.api.archiveReconciledOperation({ operation, chain })).toBe(false);
    expect((await harness.api.getReconciliationReport()).fenced).toBe(true);
  });

  it("markDestinationKeysRevoked resolves the runner's protected row, not just the session intent", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    const { chain: addKeyChain } = createChainDouble();
    await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain: addKeyChain });

    // A real signed/finalized runner row now exists. The previous implementation cleared only the
    // SDK session's intent list, so `clear()` stayed fenced by `hasProtectedRecovery()`.
    await expect(
      harness.api.markDestinationKeysRevoked({
        transferSessionId: SESSION_ID,
        accounts: START_INPUT.accounts,
      }),
    ).rejects.toThrow("new_key_transfer_revoke_chain_required");

    const stillLive = createChainDouble({ destinationLive: true });
    await expect(
      harness.api.markDestinationKeysRevoked({
        transferSessionId: SESSION_ID,
        accounts: START_INPUT.accounts,
        chain: stillLive.chain,
      }),
    ).rejects.toThrow("new_key_transfer_revoke_destination_key_present");

    // Host removed the key with the source signer and waited for finality.
    const removed = createChainDouble({ destinationLive: false });
    const revoked = await harness.api.markDestinationKeysRevoked({
      transferSessionId: SESSION_ID,
      accounts: START_INPUT.accounts,
      chain: removed.chain,
    });
    expect(revoked.addKeyIntentAccounts).toEqual([]);
    // The AddKeys committed their verification proof; revocation alone must not touch it…
    expect((await harness.api.getRecoveryState()).pendingVerification).not.toBeNull();
    await expect(harness.api.clear(CLIENT_ID)).resolves.toBeUndefined();
    expect(await harness.api.getSessions()).toEqual([]);
    // …but `clear()` after a full revoke must release the one-slot proof too, or the NEXT
    // transfer's own `commitVerificationIntent` dies on `pending_verify_conflict` with no
    // public way out.
    expect((await harness.api.getRecoveryState()).pendingVerification).toBeNull();
  });

  it("fences a corrupt journal with a support reference and no evidence to act on", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await harness.storage.implementation.setItem(ADD_KEY_JOURNAL_KEY, "{ not json");

    const report = await harness.api.getReconciliationReport();
    expect(report.fenced).toBe(true);
    expect(report.reason).toBe("journal_unreadable");
    expect(report.operations).toEqual([]);
    expect(report.supportReference).toMatch(/^MCNKT(-[A-Z2-7]{4}){4}$/);
  });
});

// ─────────────────────────────────────────────────────────────────────────────────────────────
// Stabilization SD-series behaviors (PLAN-new-key-transfer-stabilization.md Phase 2)
// ─────────────────────────────────────────────────────────────────────────────────────────────

const VERIFY_PENDING_OUTPUT: TNewKeyTransferVerifyActiveOutputV1 = {
  formatVersion: 1,
  transferSessionId: SESSION_ID,
  accounts: [
    {
      blockchainId: "near",
      networkId: "testnet",
      accountId: "alice.testnet",
      activation: "verified_pending_completion",
      pendingFact: "import_incomplete",
    },
  ],
};

/** A different, valid 32-byte base58 value to play a drifted activation hash. */
const OTHER_TRANSACTION_HASH = "cGfHiC6Kgg3FpFZvgwGcswsCRtp4aBP2fzuXRQPizuN";

const fullFlowToVerified = async (harness: ReturnType<typeof createHarness>) => {
  await harness.api.start({
    clientTransferId: CLIENT_ID,
    targetPlatform: "web",
    accounts: START_INPUT.accounts,
  });
  const { chain } = createChainDouble();
  await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain });
  return harness.api.verifyActive({
    transferSessionId: SESSION_ID,
    activations: VERIFY_INPUT.activations,
  });
};

describe("stabilization: SD4/SD6 completion facts", () => {
  it("holds a pending-completion row open, converges on secured, then replays from cache", async () => {
    const harness = createHarness({
      outputs: [START_OUTPUT, VERIFY_PENDING_OUTPUT, VERIFY_OUTPUT],
    });
    const pendingResult = await fullFlowToVerified(harness);
    expect(pendingResult.session.phase).toBe("verification_pending_wallet");
    expect(pendingResult.session.pendingCompletionAccounts).toHaveLength(1);
    expect(pendingResult.session.securedAccounts).toHaveLength(0);
    // The pending proof is retained for the retry — never cleared on a non-terminal exchange.
    expect((await harness.api.getRecoveryState()).pendingVerification).not.toBeNull();

    const converged = await harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: VERIFY_INPUT.activations,
    });
    expect(converged.session.phase).toBe("destination_keys_verified");
    expect(converged.session.securedAccounts).toHaveLength(1);
    expect(converged.session.pendingCompletionAccounts).toHaveLength(0);
    expect((await harness.api.getRecoveryState()).pendingVerification).toBeNull();
    expect(harness.getPromptCount()).toBe(3);

    // SDK-4 exact_cached_result: a byte-identical repeat of the TERMINAL exchange answers from
    // the durable cache without asking the wallet again.
    const replayed = await harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: VERIFY_INPUT.activations,
    });
    expect(replayed.output).toEqual(VERIFY_OUTPUT);
    expect(replayed.session.phase).toBe("destination_keys_verified");
    expect(harness.getPromptCount()).toBe(3);
  });

  it("refuses an activation hash that contradicts this transfer's own finalized journal", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, VERIFY_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    const { chain } = createChainDouble();
    await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain });
    const drifted = harness.api.verifyActive({
      transferSessionId: SESSION_ID,
      activations: [
        { ...VERIFY_INPUT.activations[0], addKeyTransactionHash: OTHER_TRANSACTION_HASH },
      ],
    });
    await expect(drifted).rejects.toThrow("new_key_transfer_verify_hash_mismatch");
    await drifted.catch((error) => {
      expect(error).toBeInstanceOf(NewKeyTransferError);
      expect((error as NewKeyTransferError).code).toBe("new_key_transfer_verify_hash_mismatch");
    });
  });
});

describe("stabilization: SDK-1 fence agrees with the reconciliation report", () => {
  it("does not fence a signed row that is still bound to its start result", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, SECOND_START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    // An ambiguous broadcast: the signed row exists, the start result is intact. Resumable
    // through `runAddKeys` — and per SDK-1 it must NOT brick unrelated transfers.
    await harness.storage.implementation.setItem(
      ADD_KEY_JOURNAL_KEY,
      JSON.stringify({
        formatVersion: 2,
        entries: [
          {
            operationVersion: 1,
            transferSessionId: SESSION_ID,
            blockchainId: "near",
            networkId: "testnet",
            accountId: "alice.testnet",
            sourcePublicKey: SOURCE_KEY,
            destinationPublicKey: DESTINATION_KEY,
            phase: "transaction_signed",
            transactionHash: TRANSACTION_HASH,
            signedTransactionBase64: Buffer.alloc(64, 3).toString("base64"),
          },
        ],
      }),
    );
    const recovery = await harness.api.getRecoveryState();
    expect(recovery.reconciliation.fenced).toBe(false);
    // The legacy flag now IS the report's verdict — they can never disagree again.
    expect(recovery.orphanedSignedAddKey).toBe(recovery.reconciliation.fenced);
  });
});

describe("stabilization: SDK-2 start-result wedge exits", () => {
  it("clear() on a crash-window start_pending row also discards its journaled start result", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    // Simulate the crash between the wallet's answer (start result journaled, hold begun) and
    // the session commit: rewind the session row to `start_pending`.
    harness.setStoredSessions([
      {
        formatVersion: 1,
        phase: "start_pending",
        targetPlatform: "web",
        clientTransferId: CLIENT_ID,
        canonicalInputHash: hashNewKeyTransferStartInput(START_INPUT),
        startRequest: START_INPUT,
        addKeyIntentAccounts: [],
        verifiedAccounts: [],
        securedAccounts: [],
        pendingCompletionAccounts: [],
        updatedAt: Date.now(),
      },
    ]);
    expect((await harness.api.getRecoveryState()).startResult).not.toBeNull();

    await harness.api.clear(CLIENT_ID);
    expect((await harness.api.getRecoveryState()).startResult).toBeNull();
    expect(await harness.api.getSessions()).toHaveLength(0);

    // The profile is startable again — the exact wedge SDK-2 described is gone.
    const restarted = await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    expect(restarted.output).toEqual(START_OUTPUT);
  });

  it("discardOrphanedStartResult clears an unreferenced slot and refuses a referenced one", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    // Referenced by a live session → refused.
    await expect(harness.api.discardOrphanedStartResult()).rejects.toThrow(
      "new_key_transfer_start_result_referenced",
    );
    // Orphaned (no session row at all) → discarded.
    harness.setStoredSessions([]);
    expect(await harness.api.discardOrphanedStartResult()).toBe(true);
    expect((await harness.api.getRecoveryState()).startResult).toBeNull();
    expect(await harness.api.discardOrphanedStartResult()).toBe(false);
  });
});

describe("stabilization: SD10 retention", () => {
  const pendingRow = (index: number, updatedAt: number) => {
    const request: TNewKeyTransferStartInputV1 = {
      formatVersion: 1,
      clientTransferId: `RETAIN${String(index).padStart(16, "0")}`,
      accounts: START_INPUT.accounts,
    };
    return {
      formatVersion: 1,
      phase: "start_pending",
      targetPlatform: "web",
      clientTransferId: request.clientTransferId,
      canonicalInputHash: hashNewKeyTransferStartInput(request),
      startRequest: request,
      addKeyIntentAccounts: [],
      verifiedAccounts: [],
      securedAccounts: [],
      pendingCompletionAccounts: [],
      updatedAt,
    };
  };

  it("surfaces capacity as a typed retention error, and sweeps stale pending rows", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    const fresh = Array.from({ length: 100 }, (_, index) => pendingRow(index, Date.now()));
    harness.setStoredSessions(fresh);
    const overflow = harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await expect(overflow).rejects.toThrow("new_key_transfer_journal_retention_required");
    await overflow.catch((error) => {
      expect((error as NewKeyTransferError).code).toBe(
        "new_key_transfer_journal_retention_required",
      );
    });

    // The same 100 rows, stale: swept automatically and the start proceeds.
    const stale = Array.from({ length: 100 }, (_, index) =>
      pendingRow(index, Date.now() - 2 * 60 * 60 * 1000),
    );
    harness.setStoredSessions(stale);
    const started = await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    expect(started.output).toEqual(START_OUTPUT);
    expect((await harness.api.getSessions()).length).toBe(1);
  });

  it("archives a fully secured transfer and refuses to archive unfinished ones", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, VERIFY_OUTPUT] });
    const verified = await fullFlowToVerified(harness);
    expect(verified.session.phase).toBe("destination_keys_verified");

    await harness.api.archiveCompletedSession(CLIENT_ID);
    expect(await harness.api.getSessions()).toHaveLength(0);
    // Terminal retirement also releases the one-slot start-result journal for the next transfer.
    expect((await harness.api.getRecoveryState()).startResult).toBeNull();
    await expect(harness.api.archiveCompletedSession(CLIENT_ID)).rejects.toThrow(
      "new_key_transfer_session_not_found",
    );

    const second = createHarness({ outputs: [START_OUTPUT] });
    await second.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    await expect(second.api.archiveCompletedSession(CLIENT_ID)).rejects.toThrow(
      "new_key_transfer_session_not_terminal",
    );
  });
});

describe("full host storage", () => {
  /** A completed-session stand-in big enough that freeing it makes real room. */
  const archivedFiller = Array.from({ length: 20 }, (_, index) => ({
    clientTransferId: `ARCHIVED${index}`,
    padding: "x".repeat(2_000),
  }));

  it("refuses a start with a typed code, before prompting, when nothing can be freed", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    harness.setJsonQuotaHeadroom(0);

    const refused = harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });

    await expect(refused).rejects.toThrow("new_key_transfer_storage_full");
    await refused.catch((error) => {
      expect(error).toBeInstanceOf(NewKeyTransferError);
      expect((error as NewKeyTransferError).cause).toBeInstanceOf(DOMException);
      expect(((error as NewKeyTransferError).cause as DOMException).name).toBe(
        "QuotaExceededError",
      );
    });
    expect(harness.getPromptCount()).toBe(0);
    expect(await harness.api.getSessions()).toEqual([]);
  });

  it("drops the write-only archive to make room, and the start proceeds", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT] });
    harness.values.set("newKeyTransferArchivedSessions", archivedFiller);
    harness.setJsonQuotaHeadroom(0);

    const started = await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });

    expect(started.output).toEqual(START_OUTPUT);
    expect(harness.values.has("newKeyTransferArchivedSessions")).toBe(false);
    expect(await harness.api.getSessions()).toHaveLength(1);
  });

  it("still retires a completed session when even its archive copy cannot be written", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, VERIFY_OUTPUT] });
    await fullFlowToVerified(harness);
    harness.values.set("newKeyTransferArchivedSessions", archivedFiller);
    harness.setJsonQuotaHeadroom(0);

    await harness.api.archiveCompletedSession(CLIENT_ID);

    expect(await harness.api.getSessions()).toEqual([]);
    expect(harness.values.has("newKeyTransferArchivedSessions")).toBe(false);
    expect((await harness.api.getRecoveryState()).startResult).toBeNull();
  });
});

describe("stabilization: SD11 typed errors and validate-before-effect", () => {
  it("raises NewKeyTransferError with stable codes and recovery fences", async () => {
    const harness = createHarness({ outputs: [START_OUTPUT, VERIFY_OUTPUT] });
    await fullFlowToVerified(harness);
    const blocked = harness.api.clear(CLIENT_ID);
    await expect(blocked).rejects.toThrow("new_key_transfer_recovery_required");
    await blocked.catch((error) => {
      expect(error).toBeInstanceOf(NewKeyTransferError);
      expect((error as NewKeyTransferError).fence).toBe("session_intent");
    });

    harness.api.configure(false);
    const disabled = harness.api.start({
      clientTransferId: SECOND_CLIENT_ID,
      targetPlatform: "web",
      accounts: SECOND_START_INPUT.accounts,
    });
    await expect(disabled).rejects.toThrow("new_key_transfer_unavailable");
  });

  it("validates revocation identity before touching any fence evidence", async () => {
    // Stop after the AddKey window: the finalized journal row is live fence evidence here.
    const harness = createHarness({ outputs: [START_OUTPUT] });
    await harness.api.start({
      clientTransferId: CLIENT_ID,
      targetPlatform: "web",
      accounts: START_INPUT.accounts,
    });
    const { chain } = createChainDouble();
    await harness.api.runAddKeys({ transferSessionId: SESSION_ID, chain });
    const journalBefore = await harness.storage.implementation.getItem(ADD_KEY_JOURNAL_KEY);
    expect(JSON.parse(journalBefore ?? "{}").entries?.length ?? 0).toBeGreaterThan(0);

    // Unknown transfer session → refused up front, no journal mutation attempted.
    await expect(
      harness.api.markDestinationKeysRevoked({
        transferSessionId: "Z".repeat(22),
        accounts: START_INPUT.accounts,
      }),
    ).rejects.toThrow("new_key_transfer_session_not_found");
    // An account outside the intent set → refused up front.
    await expect(
      harness.api.markDestinationKeysRevoked({
        transferSessionId: SESSION_ID,
        accounts: [{ blockchainId: "near", networkId: "testnet", accountId: "mallory.testnet" }],
      }),
    ).rejects.toThrow("new_key_transfer_revoke_account_mismatch");
    // The fence evidence is byte-identical after both refusals (SDK-9: validate before effect).
    expect(await harness.storage.implementation.getItem(ADD_KEY_JOURNAL_KEY)).toBe(journalBefore);
  });
});
