import type { PublicKey } from "@near-js/crypto";
import type { SignedMessage } from "@near-js/signers";
import type { FinalExecutionOutcome } from "@near-js/types";
import type { TNearNativeAction } from "../../near_utils/meteor_actions.types";
import type {
  IODappAction_VerifyOwner_Output,
  IORequestSignDelegateActions_Output,
} from "../../ported_common/dapp/dapp.types";
import type { PartialBy } from "../../ported_common/utils/special_typescript_types";
import type {
  IMeteorConnectAccount,
  IMeteorConnectAccountIdentifier,
} from "../MeteorConnect.types.ts";
import type {
  IMCAction_WithExactAccountTarget,
  IMCAction_WithFullAccount,
  IMCAction_WithNetworkTarget,
  IMCActionSchema,
  TMCActionId,
} from "./mc_action.types.ts";

//
// SIGN IN ACTIONS
//
// ---------------

// (FUNCTION CALL KEY PARAMS)

export interface FunctionCallAccessKey_AllowMethods_AnyMethod {
  anyMethod: true;
}

export interface FunctionCallAccessKey_AllowMethods_SelectMethods {
  anyMethod: false;
  methodNames: string[];
}

export type AddFunctionCallKey_AllowMethods =
  | FunctionCallAccessKey_AllowMethods_AnyMethod
  | FunctionCallAccessKey_AllowMethods_SelectMethods;

export interface FunctionCallAccessKey_GasAllowance_Unlimited {
  kind: "unlimited";
}

export interface FunctionCallAccessKey_GasAllowance_Limited {
  kind: "limited";
  /** The amount of gas allowed over the lifetime of the key in yoctoNEAR. */
  amount: string;
}

export type AddFunctionCallKey_GasAllowance =
  | FunctionCallAccessKey_GasAllowance_Unlimited
  | FunctionCallAccessKey_GasAllowance_Limited;

export interface AddFunctionCallKeyParams {
  // The contract / account ID which the access key will have access to call methods on.
  contractId: string;
  /** Using format "<key_type>:<base58_public_key>" e.g. "ed25519:3N5QmbhVqLh9ZtZs1zj8X9v1u1Z1Z1Z1Z1Z1Z1Z1Z1Z" */
  publicKey: string;
  allowMethods: AddFunctionCallKey_AllowMethods;
  /** Optional:  The gas allowance for the function call key over its lifetime of executing transactions.
   *  Default to "limited" with 0.25 NEAR (non-Yocto). */
  gasAllowance?: AddFunctionCallKey_GasAllowance;
}

// SIGN IN PARAMS

export interface IMCAInput_Near_SignIn_BaseParams {
  /** @deprecated use addFunctionCallKey */
  contract?: {
    id: string;
    methods?: string[];
  };
  /**
   * If this is provided, the connector will filter for wallets that support the "signInWithFunctionCallAccessKey" feature and use these
   * params to add a function call access key during sign in.
   *
   * These params indicate to the wallet that a Function Call Key with these parameters should be added during the sign in process with the specified parameters.
   *
   * See: https://docs.near.org/protocol/access-keys#function-call-keys
   */
  addFunctionCallKey?: PartialBy<AddFunctionCallKeyParams, "publicKey">;
}

export interface IMCAInput_Near_SignIn
  extends IMCAInput_Near_SignIn_BaseParams,
    IMCAction_WithNetworkTarget {}

// (WITH SIGN MESSAGE)

export interface IMCAInput_Near_SignInAndSignMessage extends IMCAInput_Near_SignIn {
  messageParams: INearSignMessageParams;
}

export interface IMCAOutput_Near_SignInAndSignMessage extends IMeteorConnectAccount {
  signedMessage: SignedMessage;
}

// ------------------------------
//
// ACTIONS WITH SIGNED-IN ACCOUNT
//
// ------------------------------

//
// SIGN MESSAGE (WITH ACCOUNT)
//

export interface INearSignMessageParams {
  message: string;
  recipient: string;
  nonce: Uint8Array;
  callbackUrl?: string;
  state?: string;
}

export interface IMCAInput_Near_SignMessage extends IMCAction_WithExactAccountTarget {
  messageParams: INearSignMessageParams;
}

//
// VERIFY OWNER
//

export interface IMCAInput_Near_VerifyOwner extends IMCAction_WithExactAccountTarget {
  message: string;
}

//
// SIGN TRANSACTIONS
//

export type TSimpleNearTransaction = {
  receiverId: string;
  actions: TNearNativeAction[];
};

// export type TSimpleNearTransaction_DelegateAction = {
//   receiverId: string;
//   actions: DelegateAction[];
// };

export interface IMCA_Near_SignTransactions_Input extends IMCAction_WithExactAccountTarget {
  transactions: TSimpleNearTransaction[];
  /**
   * Default `true`: when the account signed in with a function-call key (`addFunctionCallKey`)
   * that covers every transaction — calls to that contract, allowed methods, no deposit — they are
   * signed and sent with it directly, without opening the wallet. Anything it does not cover (a
   * deposit, another contract) still goes to the wallet. Set `false` to always ask the wallet.
   */
  useFunctionCallKey?: boolean;
}

//
// SIGN DELEGATE ACTIONS
//

export interface INearNativeDelegateAction {
  senderId: string;
  receiverId: string;
  actions: Array<TNearNativeAction>;
  nonce: bigint;
  maxBlockHeight: bigint;
  publicKey: PublicKey;
}

export type TSimpleNearDelegateAction = Omit<
  INearNativeDelegateAction,
  "senderId" | "publicKey" | "nonce" | "blockHash" | "maxBlockHeight"
>;

export interface IMCA_Near_SignDelegateActions_Input extends IMCAction_WithExactAccountTarget {
  delegateActions: TSimpleNearDelegateAction[];
}

// --------------------------
//
// NEAR ACTION DEFINITION MAP
//
// --------------------------

export const MCNearActions = {
  "near::sign_in": {
    input: {} as IMCAInput_Near_SignIn,
    expandedInput: {} as IMCAInput_Near_SignIn,
    output: {} as IMeteorConnectAccount,
    meta: {
      executionTargetSource: "on_execution",
    },
  },
  "near::sign_in_and_sign_message": {
    input: {} as IMCAInput_Near_SignInAndSignMessage,
    expandedInput: {} as IMCAInput_Near_SignInAndSignMessage,
    output: {} as IMCAOutput_Near_SignInAndSignMessage,
    meta: {
      executionTargetSource: "on_execution",
    },
  },
  "near::sign_out": {
    input: {} as IMCAction_WithExactAccountTarget,
    expandedInput: {} as IMCAction_WithFullAccount,
    output: {} as IMeteorConnectAccountIdentifier,
    meta: {
      inputTransform: ["targeted_account"],
      executionTargetSource: "targeted_account",
    },
  },
  "near::sign_message": {
    input: {} as IMCAInput_Near_SignMessage,
    expandedInput: {} as IMCAInput_Near_SignMessage & IMCAction_WithFullAccount,
    output: {} as SignedMessage,
    meta: {
      inputTransform: ["targeted_account"],
      executionTargetSource: "targeted_account",
    },
  },
  "near::sign_transactions": {
    input: {} as IMCA_Near_SignTransactions_Input,
    expandedInput: {} as IMCA_Near_SignTransactions_Input & IMCAction_WithFullAccount,
    output: {} as FinalExecutionOutcome[],
    meta: {
      inputTransform: ["targeted_account"],
      executionTargetSource: "targeted_account",
    },
  },
  "near::sign_delegate_actions": {
    input: {} as IMCA_Near_SignDelegateActions_Input,
    expandedInput: {} as IMCA_Near_SignDelegateActions_Input & IMCAction_WithFullAccount,
    output: {} as IORequestSignDelegateActions_Output,
    meta: {
      inputTransform: ["targeted_account"],
      executionTargetSource: "targeted_account",
    },
  },
  "near::verify_owner": {
    input: {} as IMCAInput_Near_VerifyOwner,
    expandedInput: {} as IMCAInput_Near_VerifyOwner & IMCAction_WithFullAccount,
    output: {} as IODappAction_VerifyOwner_Output,
    meta: {
      inputTransform: ["targeted_account"],
      executionTargetSource: "targeted_account",
    },
  },
} as const satisfies Record<TMCActionId<"near">, IMCActionSchema>;
