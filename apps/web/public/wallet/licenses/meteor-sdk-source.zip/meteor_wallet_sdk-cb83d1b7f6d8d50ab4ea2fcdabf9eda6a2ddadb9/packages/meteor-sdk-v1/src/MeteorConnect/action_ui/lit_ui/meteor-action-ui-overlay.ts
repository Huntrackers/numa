import { isMobile } from "../utils/isMobile";
import { provide } from "@lit/context";
import { css, html, LitElement } from "lit";
import { property } from "lit/decorators.js"; // You MUST import this explicitly
import { MeteorLogger } from "../../logging/MeteorLogger";
import { METEOR_ACTION_UI_POPUP_PARENT_ID } from "../action_ui.static";
import { customElement } from "./custom-element"; // Your new util
import { overlayCloseTriggerContext } from "./meteor-action-ui-context";

@customElement("meteor-action-ui-overlay")
export class MeteorActionUiOverlay extends LitElement {
  private logger = MeteorLogger.createLogger("MeteorConnect:<meteor-action-ui-overlay>");

  private _originalCloseAction: (() => void) | null = null;
  private _wrappedCloseAction: (() => void) | null = null;

  // Wrap closeAction to always use animated close
  @property({ type: Function })
  set closeAction(value: (() => void) | null) {
    this._originalCloseAction = value;
    // Create wrapped version that triggers animation
    this._wrappedCloseAction = value ? () => this._animateClose() : null;
  }
  get closeAction(): (() => void) | null {
    return this._wrappedCloseAction;
  }

  @property({ type: Boolean }) private closing: boolean = false;
  @property({ attribute: false }) canClose?: () => boolean;
  @property({ attribute: false }) canCloseOnBackdrop?: () => boolean;

  @provide({ context: overlayCloseTriggerContext })
  @property({ attribute: false })
  private overlayCloseTrigger = () => this._animateClose();

  static styles = css`
      @keyframes fadeIn {
        from {
          opacity: 0;
        }
        to {
          opacity: 1;
        }
      }

      @keyframes scaleInUp {
        from {
          opacity: 0;
          transform: scale(0.92) translateY(10px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }

      @keyframes fadeOut {
        from {
          opacity: 1;
        }
        to {
          opacity: 0;
        }
      }

      @keyframes scaleOutDown {
        from {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
        to {
          opacity: 0;
          transform: scale(0.95) translateY(8px);
        }
      }

      :host {
        top: var(--meteor-viewport-top, 0px);
        left: var(--meteor-viewport-left, 0px);
        width: var(--meteor-viewport-width, 100vw);
        height: var(--meteor-viewport-height, 100dvh);
        display: flex;
        align-items: center;
        justify-content: center;
        position: fixed;
        z-index: 10000;
        pointer-events: auto;
        /* filter: blur(20px); */
        /* filter: blur(0.5px) drop-shadow(0 0 2px rgba(0, 0, 0, 0.3)); */
      }

      :host(:not([closing])) {
        animation: fadeIn 300ms ease-out forwards;
      }

      :host([closing]) {
        animation: fadeOut 250ms ease-in forwards;
      }

      .modal-backdrop {
        position: absolute;
        inset: 0;
        background-color: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(20px);
      }

      :host(:not([closing])) .modal-backdrop {
        animation: fadeIn 300ms ease-out forwards;
      }

      :host([closing]) .modal-backdrop {
        animation: fadeOut 250ms ease-in forwards;
      }

      .modal-container {
        z-index: 2;
        height: min(556px, calc(var(--meteor-viewport-height, 100dvh) - 2rem));
        width: min(415px, calc(var(--meteor-viewport-width, 100vw) - 2rem));
        border-radius: 1.2em;
        border: 1px solid #2b2d38;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      }

      :host([connect-design]) .modal-container {
        box-sizing: border-box;
        height: auto;
        width: min(480px, calc(var(--meteor-viewport-width, 100vw) - 1rem));
        min-height: min(670px, calc(var(--meteor-viewport-height, 100dvh) - 1rem));
        max-height: calc(var(--meteor-viewport-height, 100dvh) - 1rem);
      }

      :host([connect-design][mobile-device]) .modal-container {
        min-width: min(500px, calc(var(--meteor-viewport-width, 100vw) - 1rem));
        min-height: min(380px, calc(var(--meteor-viewport-height, 100dvh) - 1rem));
      }

      :host(:not([closing])) .modal-container {
        animation: scaleInUp 400ms cubic-bezier(0.16, 1, 0.3, 1) forwards;
      }

      :host([closing]) .modal-container {
        animation: scaleOutDown 250ms ease-in forwards;
      }
    `;

  private _handleOverlayClick() {
    if (this.closing) return; // Prevent multiple close triggers
    if (this.canCloseOnBackdrop?.() === false) return;
    this.logger.log("Overlay backdrop clicked, closing with animation");
    this._animateClose();
  }

  private _animateClose() {
    if (this.closing) return;
    if (this.canClose?.() === false) return;
    this.logger.log("Starting close animation");
    this.closing = true;

    // Wait for animation to complete before actually closing
    setTimeout(() => {
      // Call the original closeAction to perform actual cleanup
      if (this._originalCloseAction) {
        try {
          this._originalCloseAction();
        } catch (e) {
          this.logger.log("Error during closeAction", e);
        }
      } else {
        this.remove();
      }
    }, 250); // Match the fadeOut animation duration
  }

  private observedViewport?: VisualViewport;
  private syncViewport = () => {
    const viewport = window.visualViewport;
    this.style.setProperty("--meteor-viewport-width", `${viewport?.width ?? window.innerWidth}px`);
    this.style.setProperty("--meteor-viewport-height", `${viewport?.height ?? window.innerHeight}px`);
    this.style.setProperty("--meteor-viewport-top", `${viewport?.offsetTop ?? 0}px`);
    this.style.setProperty("--meteor-viewport-left", `${viewport?.offsetLeft ?? 0}px`);
  };

  connectedCallback() {
    super.connectedCallback();
    this.syncViewport();
    this.observedViewport = window.visualViewport ?? undefined;
    this.observedViewport?.addEventListener("resize", this.syncViewport);
    this.observedViewport?.addEventListener("scroll", this.syncViewport);
    window.addEventListener("resize", this.syncViewport);
    // Ensure cleanup recognizes this as the popup overlay container
    this.id = METEOR_ACTION_UI_POPUP_PARENT_ID;
    // Register click on the host so backdrop clicks are captured
    this.addEventListener("click", this._handleOverlayClick);
  }

  disconnectedCallback(): void {
    this.observedViewport?.removeEventListener("resize", this.syncViewport);
    this.observedViewport?.removeEventListener("scroll", this.syncViewport);
    window.removeEventListener("resize", this.syncViewport);
    this.observedViewport = undefined;
    // Clean up the listener to avoid leaks
    this.removeEventListener("click", this._handleOverlayClick);
    super.disconnectedCallback();
  }

  render() {
    if (import.meta.hot) {
      import.meta.hot.accept();
    }
    this.logger.log("Rendering MeteorActionUiOverlay", { closing: this.closing });

    // Update the closing attribute for CSS selector
    if (this.closing) {
      this.setAttribute("closing", "");
    } else {
      this.removeAttribute("closing");
    }

    return html`
      <div>
        <div class="modal-backdrop"></div>
        <div class="modal-container" role="dialog" aria-modal="true" aria-label="Meteor Connect" @click=${(e: Event) => e.stopPropagation()}>
          <slot @slotchange=${(event: Event) => {
            const slot = event.target as HTMLSlotElement;
            this.toggleAttribute("mobile-device", isMobile());
            this.toggleAttribute("connect-design", slot.assignedElements().some(element => ["meteor-action-ui-container", "meteor-transfer-accounts-container"].includes(element.localName)));
          }}></slot>
        </div>
      </div>
    `;
  }
}

// /* @click=${(e: Event) => e.stopPropagation()} */
