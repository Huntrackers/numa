# Meteor UI standard

The user approved the current Meteor Connect / Meteor Transfer styling as the baseline for future UI work. Prefer the validated desktop styling when resolving differences; mobile shares its visual language with an intentionally simpler layout. Explicit later user requests supersede this baseline.

## Shared implementation

- `meteor-connect-layout.styles.ts`: shared shell, typography, buttons, spacing, footer and responsive styling. Both containers consume this directly; change shared styles instead of copying them.
- `meteor-mobile-bridge-panel.ts`: shared loading, QR, pairing and connection states; `connectDesign` enables this design.
- `meteor-action-ui-overlay.ts`: responsive minimum dimensions.
- `graphical/meteor-header-logo.ts`: approved static SVG for headers.
- `graphical/meteor-connect-logo.ts`: animated GIF for continuation screens.

Connect and Transfer still own separate markup and behavior. Preserve their action-specific semantics.

## Typography

Use Gilroy, natural (`normal`) line heights, and zero letter spacing for the main labels and buttons. Do not restore the original fixed 50px or 16px line heights.

| Element | Current size | Weight |
| --- | --- | --- |
| Header | 22px | 500 Medium |
| Platform buttons | 16px | 600 SemiBold |
| Chooser heading and mobile divider (including “mobile”) | 16px | 400 Regular |
| Scan heading | 16px | 400 Regular |
| QR generation message | 12px | 400 Regular |
| Footer | `calc(1.15rem - 4px)` | inherited 500 |

The user reduced all sizes by a total of 4px. The shared bridge panel receives `--mc-font-size-reduction: 4px` and `--mc-line-height: normal`; avoid subtracting another 4px from already adjusted values. Countdown/open controls use `calc(.95rem - 4px)`.

## Surfaces and controls

- Modal: `#0e0e18`; QR/loading card: `#12121D`; footer: `#12121e`.
- Primary button: 110-degree gradient `#4210ec` → `#602cff`.
- Secondary button: `#21213f`; disabled: `#29263f` with `#aaa6bf` text and no hover highlight.
- Muted labels: `#999`; divider text: `#777`; wallet link: `#8060ff`.
- Button radius: `.4rem`; minimum height: `3rem`; padding: `.65rem .8rem`; icon/text gap: `.5rem`; icons: `1.6rem`.
- Keep visible keyboard focus and accessible loading/disabled semantics.
- Header uses the supplied static white SVG in a fixed `2.5rem` box with `object-fit: contain`, without the old GIF scaling.

## Spacing and sizing

- Content padding: `1rem 1rem 0`; section gap: `.8rem`.
- Chooser heading/button gap: `.75rem` (`.65rem` on short viewports).
- Platform grid gap: `.5rem`; mobile divider gap: `1rem` (`.75rem` on narrow screens).
- Header padding: `.8rem 1.2rem`, minimum height `4.25rem`; short viewport: `.65rem 1.2rem`, minimum `4rem`; narrow viewport: `.8rem 1rem`.
- Footer padding: `1rem` (vertical `.8rem` on short viewports), negative side margins matching content padding, `margin-top: auto` so it reaches the bottom.
- Outer modal minimum width: 480px on desktop, 500px on mobile (viewport-capped); desktop minimum height: 670px; mobile minimum height: 380px. Dimensions are automatic and capped to viewport minus 1rem. Inner minimum heights account for the 2px border.
- Retain QR scannability: current plain code with no center logo, 216px normally / 180px on short viewports. Do not scale the QR down with text.

## Desktop/mobile behavior

- Desktop: platform buttons side by side; conditional Dev Web (Localhost) on a full-width second row. Mobile QR/loading card below, no Open Meteor Mobile button on desktop.
- Mobile: stacked Meteor Mobile primary and Meteor Web secondary buttons; no extension or QR/toggle. Preserve the existing dev-option visibility rule.
- Dev-only mobile wallet switch: under the same gate as Dev Web (Localhost) (development build or force-dev flag), and only when the host is on a deployed bridge backend, Connect shows a compact Dev / Prod segmented control at the end of the “or connect with mobile” divider on desktop; on mobile, or wherever that divider is absent, it is its own “Mobile wallet (dev only)” row below the buttons. Switching re-prepares the mobile request against that environment's backend and mobile wallet build, so the QR opens it. Hidden once the platform is locked or Meteor Mobile is selected, and disabled while the request prepares.
- Create the mobile request eagerly. Until its link is ready, keep the mobile icon and “Meteor Mobile” visible in the disabled button; show a small spinner inside the button at its trailing edge with an accessible preparing-connection label. Do not add a loading row above the button or replace its label.
- Clicking Meteor Mobile directly calls the same `openCurrentSessionInApp` path as Open Meteor Mobile; do not toggle the QR/connection panel on click. Session advancement can reveal required pairing/approval states.
- Get Meteor Wallet keeps internal installation navigation despite the arrow decoration.
- No cancel-request or refresh-code button on these redesigned pages. Retain header close behavior and existing protocol lifecycle/recovery behavior. The one exception is the failure card's **Try Again** for a request no wallet took part in (see Failure card).

Verify desktop and real phone-width previews when changing layout. Use package-local TypeScript checks; run relevant tests from `packages/meteor-sdk-v1` so its decorator configuration is applied.

## Compact frames (NEAR Connect)

Inside NEAR Connect the UI renders without the overlay, straight into near-connect's sandbox iframe, whose viewport is the frame itself: 418x557 on a desktop host (near-connect caps its popup at 420x615 including its own footer and offers wallets no resize API), and full width by 80% of the screen minus that footer on a phone host (390x618 on an 844px phone).

- Below 640px of viewport height a compact tier applies: 3.25rem header with a 2.1rem logo and 2.4rem close button, .75rem content top padding and .55rem section gaps, 2.6rem platform buttons, a tighter mobile panel and footer. The QR keeps its 180px compact size; the chrome around it gives up the room.
- At 480px wide or less, desktop platform buttons use .5rem inline padding so “Chrome Extension” stays on one line.
- The failure card compacts too: 1rem padding, a 64px warning graphic, and a 2.6rem Try Again button, so the desktop chooser plus the card fit the 418x557 frame without scrolling.
- Verify with `node ./preview/action-ui/screenshot.mjs --near-connect`, which renders every scenario at those frame sizes and reports overflow. Only the QR-revealed PIN stage (`pin-qr`) may scroll, as it does at every size.

## Transfer after platform selection

Transfer now navigates to a centered continuation screen after choosing a platform (including mobile). Show the approved GIF, “Creating secure request” while preparing, then “Continue in [wallet]” and platform-specific instructions. Retain the expiry countdown, link recovery, and a primary-gradient “Open [wallet]” button on this screen, including desktop. Reuse the eagerly prepared mobile request. Keep PIN, identity recovery, key reveal and terminal states functional. This Transfer-specific flow supersedes the chooser-only mobile click rule above; Connect retains that rule.

## Shared continuation presentation

`meteor-wallet-continuation.ts` owns the centered GIF, platform-aware copy, loading indicator and primary Open button for Connect and Transfer. Bridge sessions provide “Session expires in” and recovery UI via slots. Legacy executing actions have no session deadline or safe reopen callback, so those controls are omitted rather than restarting an active action. The pre-execution known-platform screen passes its existing continue callback.

## Get Meteor Wallet

Connect and Transfer share `get-meteor-screen.ts`: an orbital smiling-meteor illustration, “Get Meteor Wallet” heading, “Your gateway to the NEAR Universe” subtitle, and a two-column grid of secondary links (Extension, Web, Android, iOS). Installation destinations are independent of the current action's supported platforms; hide Extension on mobile devices and show only the matching native store (Android on Android; iOS on iPhone/iPad, including iPad desktop-mode user agents). Keep Web available and both stores visible on desktop. Keep the existing header back and close controls. Use the explicit store URLs in that component, including the Google Play `hl=en` parameter.

On the desktop Transfer chooser, always display Chrome Extension with `svg_icons_text.icon_chrome` in the second slot. Disable it using the shared disabled button style when the transfer type or extension capability does not support it. Keep it absent on mobile.

For a mobile-wallet continuation, desktop browsers show the session QR in the centered visual slot and hide Open Meteor Mobile; mobile devices show the primary Open Meteor Mobile button without a QR. The session countdown stays visible in both. Web/extension wallet continuations retain their own Open control.

First-time mobile linking (`wallet_confirmation`) navigates Connect and Transfer out of the platform chooser into the dedicated mobile continuation screen, including the standard scan/open instructions. Hide platform choices and the chooser footer on this screen; do not merely replace the inline panel or show a separate “Confirm link” panel. Wallet-side approval and subsequent PIN verification remain unchanged.

QR loading and ready states must use the same panel, heading, frame, controls and status-row layout. `meteor-qr-layout.ts` exports the 216px/180px code sizes and 5px frame padding (226px/190px framed sizes). Reserve that complete frame footprint before generating the SVG; keep the status row at least 18px high to avoid shifting when loading text becomes the countdown.

## Returning from the wallet

The shared continuation also owns a neutral busy state (`busy`: GIF, title, message, spinner; no Open button, countdown or link pill). The bridge panel uses it, in the connect design, for:

- **Finishing** — `result_ready` and `completed`: “Finishing up” / “Completing your request with [wallet]…”. There is no “Completed in [wallet]” screen to dismiss: the action resolves and the popup closes itself. (A tab that reconnects straight into an answered turn still resolves — the action adopts the session's result for its own turn.)
- **Opening automatically** — for an account signed in with Meteor Mobile, on a phone, the SDK opens the app itself when the link is ready if the tap that started the request is still live and this browser has opened that wallet's app before (`autoOpenPairedWallet`). The screen stays the normal continuation with its Open button as the fallback; nothing new is shown for the attempt.
- **No continue screen for Meteor Mobile** — a Meteor Mobile request without a live tap goes straight to the locked bridge panel (whose Open button opens the app inside the user's tap, and whose desktop continuation shows the QR); `continue-action-screen` remains for the web and extension targets, where the tap must open the window.
- **Resuming** — the request was handed to the wallet (its link opened from this page, or the page backgrounded while the request was live) and the bridge link is `reconnecting`: “Checking request status” / “Getting the latest from [wallet]…”, in place of the “Reconnecting securely (attempt n)” pill and Open button, until the link is live again. PIN entry keeps its own stage. Before any hand-off the redial status still shows, and `offline` always keeps its Reconnect control.

## Failure card

Use the supplied `graphical/meteor-warning.ts` warning SVG above centered heading and description, on `#12121D`. Raw error details appear left-aligned in a selectable, wrapping `#181823` inset without an “Error Message” label. Generic unclassified failures use “Something Went Wrong”; preserve actionable update and cancellation headings and their explanations. Wallet context remains in the accessible label. Success and identity-reset flows retain their dedicated states.

**Before any wallet took part** (`mobileBridgeRetryableFailure`: the session failed while being created or while its link waited to be opened), the card is for the user, not the integrator — the user-requested exception of 2026-10-16, after a backend refusal reached users as “New bridge allocation is temporarily halted; retry later”:

- Copy is fixed and plain. When no QR ever existed: “Couldn’t Generate QR Code” / “We couldn’t create a secure QR code for [wallet]. Please try again.”; once a QR existed: “QR Code Expired” / “This QR code is no longer valid. Try again to get a new one.” Where no QR is offered (phones, web and extension wallets) the same states read “Couldn’t Connect to [wallet]” / “We couldn’t set up a secure connection. Please try again.” and “Request Expired” / “This request to [wallet] is no longer valid. Try again to start a new one.”
- No raw details inset and no classifier copy. The container reports those once per session to the console (`reportMobileBridgeFailure`).
- A primary-gradient **Try Again** button (centered, minimum width 10rem, standard 3rem height) sits below the description and prepares a fresh request through the container's `refreshCode`; it shows a spinner while pending, and a failure of the retry itself appears beneath it.
- On a phone the card shows under the platform choices instead of selecting Meteor Mobile: the disabled Meteor Mobile button stays, and Meteor Web stays available.
- A backend that cannot be reached at all still drops the mobile option quietly while another wallet is on offer (`isMobileBridgeQuietlyUnavailable`); the card appears only where mobile is the user's way through.

Failures a wallet already took part in keep the classified card above, unchanged.
