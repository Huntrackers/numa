import { create_bun_test_local_storage_with_adapter } from "../../../ported_common/utils/storage/bun_test/create_bun_test_local_storage";
import type { CEnvironmentStorageAdapter } from "../../../ported_common/utils/storage/EnvironmentStorageAdapter";
import type { ILocalStorageInterface } from "../../../ported_common/utils/storage/storage.types";
import {
  createTypedStorageHelper,
  type ITypedStorageHelper,
} from "../../../ported_common/utils/storage/TypedStorageHelper";
import { MeteorConnect } from "../../MeteorConnect";
import { METEOR_CONNECT_STORAGE_KEY_PREFIX } from "../../MeteorConnect.static";
import type {
  IMeteorConnectAccount,
  IMeteorConnectNetworkTarget,
  IMeteorConnectTypedStorage,
} from "../../MeteorConnect.types.ts";

interface IMeteorConnectTestInitialized {
  storageInterface: ILocalStorageInterface;
  storage: CEnvironmentStorageAdapter;
  typedStorage: ITypedStorageHelper<IMeteorConnectTypedStorage>;
  meteorConnect: MeteorConnect;
  addedAccounts: IMeteorConnectAccount[];
}

interface IInitializeMeteorConnectTest_Input {
  initialLocalStorageData?: Record<string, string | undefined>;
  addNetworkAccounts?: IMeteorConnectNetworkTarget[];
  addTestnetAccount?: boolean;
}

export async function initializeMeteorConnectTest({
  initialLocalStorageData,
  addNetworkAccounts = [],
  addTestnetAccount = false,
}: IInitializeMeteorConnectTest_Input = {}): Promise<IMeteorConnectTestInitialized> {
  const storage = create_bun_test_local_storage_with_adapter(initialLocalStorageData);
  const meteorConnect = new MeteorConnect({ isDev: true });

  const typedStorage = createTypedStorageHelper<IMeteorConnectTypedStorage>({
    storageAdapter: storage.storage,
    keyPrefix: METEOR_CONNECT_STORAGE_KEY_PREFIX,
  });

  meteorConnect.setLoggingLevel("none");

  await meteorConnect.initialize({
    storage: storage.storageInterface,
  });

  const addedAccounts: IMeteorConnectAccount[] = [];

  if (addNetworkAccounts.length === 0 && addTestnetAccount) {
    addNetworkAccounts.push({
      network: "testnet",
      blockchain: "near",
    });
  }

  if (addNetworkAccounts.length > 0) {
    for (const networkTarget of addNetworkAccounts) {
      const signInAction = await meteorConnect.createAction({
        id: "near::sign_in",
        input: {
          target: networkTarget,
        },
      });

      const response = await signInAction.execute("test");
      /*const response = await meteorConnect.actionRequest({
        id: "near::sign_in",
        input: {
          connection: {
            platformTarget: "test",
          },
          target: networkTarget,
        },
      });*/

      addedAccounts.push(response);
    }
  }

  return {
    meteorConnect,
    typedStorage,
    addedAccounts,
    ...storage,
  };
}
